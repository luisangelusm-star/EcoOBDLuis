package com.ecotrayecto.ui

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ecotrayecto.data.Observable

/** Paleta: bosque de pino, liquen, hoja, ocre de semáforo en otoño y agua. */
object Eco {
    val Pine = Color(0xFF13241C)
    val Surface = Color(0xFF1C3127)
    val Line = Color(0xFF2B4639)
    val Lichen = Color(0xFFE6EEE2)
    val Dim = Color(0xFF9AB0A2)
    val Leaf = Color(0xFF7DBA6A)
    val Ochre = Color(0xFFE3A44F)
    val Teal = Color(0xFF5BB5A2)
    val Danger = Color(0xFFE0664F)
}

/** Tipografía condensada de instrumento para las cifras, con números tabulares (no "bailan"). */
val Condensed: FontFamily = FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))

fun numberStyle(sizeSp: Int, weight: FontWeight = FontWeight.Normal) = TextStyle(
    fontFamily = Condensed, fontSize = sizeSp.sp, fontWeight = weight,
    fontFeatureSettings = "tnum", lineHeight = (sizeSp * 1.05).sp,
)

@Composable
fun EcoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Eco.Leaf, onPrimary = Eco.Pine,
            secondary = Eco.Teal, onSecondary = Eco.Pine,
            tertiary = Eco.Ochre, onTertiary = Eco.Pine,
            background = Eco.Pine, onBackground = Eco.Lichen,
            surface = Eco.Surface, onSurface = Eco.Lichen,
            surfaceVariant = Eco.Line, onSurfaceVariant = Eco.Dim,
            surfaceContainer = Eco.Surface,
            surfaceContainerHigh = Eco.Surface,
            surfaceContainerHighest = Eco.Line,
            outline = Eco.Line, outlineVariant = Eco.Line,
            error = Eco.Danger,
        ),
        typography = Typography(),
        content = content,
    )
}

/** Convierte un Observable en estado de Compose. */
@Composable
fun <T> Observable<T>.asState(): State<T> {
    val st = remember(this) { mutableStateOf(value) }
    DisposableEffect(this) {
        val unsubscribe = observe { st.value = it }
        onDispose { unsubscribe() }
    }
    return st
}

/** Hoja dibujada a mano: el sello de la app. */
@Composable
fun LeafMark(size: Dp, color: Color = Eco.Leaf, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val leaf = Path().apply {
            moveTo(w * 0.18f, h * 0.86f)
            cubicTo(w * 0.05f, h * 0.45f, w * 0.40f, h * 0.10f, w * 0.90f, h * 0.10f)
            cubicTo(w * 0.92f, h * 0.55f, w * 0.60f, h * 0.90f, w * 0.18f, h * 0.86f)
            close()
        }
        drawPath(leaf, color)
        val vein = Path().apply {
            moveTo(w * 0.12f, h * 0.95f)
            quadraticBezierTo(w * 0.45f, h * 0.55f, w * 0.78f, h * 0.24f)
        }
        drawPath(vein, Eco.Pine, style = Stroke(width = w * 0.045f, cap = StrokeCap.Round))
    }
}

/** Anillo dividido: hoja = en marcha, ocre = parado. */
@Composable
fun SplitRing(stoppedFraction: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = this.size.minDimension * 0.09f
            val d = this.size.minDimension - stroke
            val tl = Offset((this.size.width - d) / 2, (this.size.height - d) / 2)
            val sz = Size(d, d)
            drawArc(Eco.Line, 0f, 360f, false, tl, sz, style = Stroke(stroke))
            val stoppedSweep = 360f * stoppedFraction.coerceIn(0f, 1f)
            val gap = if (stoppedFraction in 0.01f..0.99f) 4f else 0f
            if (stoppedFraction < 0.995f)
                drawArc(Eco.Leaf, -90f + stoppedSweep + gap / 2, 360f - stoppedSweep - gap, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Butt))
            if (stoppedFraction > 0.005f)
                drawArc(Eco.Ochre, -90f + gap / 2, stoppedSweep - gap, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Butt))
        }
        content()
    }
}

/** Medidor semicircular para la puntuación eco. */
@Composable
fun ScoreGauge(score: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = this.size.minDimension * 0.08f
            val d = this.size.minDimension - stroke
            val tl = Offset((this.size.width - d) / 2, (this.size.height - d) / 2)
            val sz = Size(d, d)
            drawArc(Eco.Line, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (score >= 0) {
                val c = when { score >= 75 -> Eco.Leaf; score >= 50 -> Eco.Teal; else -> Eco.Ochre }
                drawArc(c, 135f, 270f * score / 100f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        content()
    }
}

/** Tensión de batería, pequeña y siempre visible. Ocre o rojo si está baja. */
@Composable
fun BatteryIndicator() {
    val live by com.ecotrayecto.data.AppState.live.asState()
    val v = live.voltage ?: return
    val engineOn = (live.rpm ?: 0) > 400
    val color = when {
        engineOn && v < 13.0 -> Eco.Ochre      // motor en marcha y poca carga: ¿alternador?
        !engineOn && v < 11.8 -> Eco.Danger
        !engineOn && v < 12.2 -> Eco.Ochre
        else -> Eco.Dim
    }
    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(width = 16.dp, height = 10.dp)) {
            val w = this.size.width; val h = this.size.height
            val sw = 1.4.dp.toPx()
            drawRect(color, Offset(sw / 2, sw / 2), Size(w * 0.86f - sw, h - sw), style = Stroke(sw))
            drawRect(color, Offset(w * 0.86f, h * 0.3f), Size(w * 0.14f, h * 0.4f))
            val fill = ((v - 11.5) / (12.7 - 11.5)).coerceIn(0.1, 1.0).toFloat()
            drawRect(color, Offset(sw * 1.8f, sw * 1.8f), Size((w * 0.86f - sw * 3.6f) * fill, h - sw * 3.6f))
        }
        androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
        androidx.compose.material3.Text(
            fmtNum(v, 1) + " V",
            style = numberStyle(15), color = color,
        )
    }
}

val TitleStyle = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Eco.Lichen)
val LabelStyle = TextStyle(fontSize = 15.sp, color = Eco.Dim)
val BodyStyle = TextStyle(fontSize = 16.sp, color = Eco.Lichen, lineHeight = 22.sp)

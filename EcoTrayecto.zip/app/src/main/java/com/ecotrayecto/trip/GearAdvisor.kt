package com.ecotrayecto.trip

import kotlin.math.abs

/** Una marcha aprendida: km/h por cada 1000 rpm. */
data class GearCluster(var ratio: Double, var count: Int)

data class GearConfig(
    val enabled: Boolean = true,
    val gearCount: Int = 5,
    val upshiftRpm: Int = 2500,       // a partir de aquí se sugiere subir
    val minRpmAfterUp: Int = 1300,    // no sugerir subir si la siguiente marcha quedaría por debajo
    val luggingRpm: Int = 1200,       // por debajo, con carga alta, sugerir bajar
    val holdMs: Long = 1200,          // la condición debe mantenerse este tiempo (absorbe el retraso del ELM)
)

/** gear y suggestion son números de marcha (1 = primera). learned = marchas aprendidas hasta ahora. */
data class GearAdvice(val gear: Int? = null, val suggestion: Int? = null, val learned: Int = 0, val ready: Boolean = false)

/**
 * Aprende las relaciones de cambio agrupando la relación velocidad/rpm cuando es estable
 * (embrague soltado) y sugiere subir o bajar de marcha. Sin Android, para poder probarlo.
 */
class GearAdvisor(initial: List<GearCluster>, @Volatile var config: GearConfig) {
    private val clusters = initial.map { it.copy() }.toMutableList()
    private val window = ArrayDeque<Pair<Long, Double>>()
    private var lastLearnMs = 0L
    private var candidate: Int? = null
    private var candidateSince = 0L
    @Volatile var changed = false
        private set

    @Synchronized
    fun onSample(now: Long, speed: Int, rpm: Int?, load: Int?): GearAdvice {
        val gears = validGears()
        val ready = gears.size >= config.gearCount
        if (!config.enabled || rpm == null || speed < 8 || rpm < 700) {
            window.clear(); candidate = null
            return GearAdvice(null, null, gears.size, ready)
        }
        val ratio = speed * 1000.0 / rpm

        // Aprendizaje: relación estable durante ~2,5 s = marcha engranada y embrague soltado.
        window.addLast(now to ratio)
        while (window.isNotEmpty() && now - window.first().first > 4000) window.removeFirst()
        if (window.size >= 3 && now - window.first().first >= 2500 && now - lastLearnMs > 2000) {
            val mean = window.sumOf { it.second } / window.size
            // A poca velocidad el ELM da km/h enteros: se tolera más variación.
            val tol = 0.025 + 0.6 / speed
            if (window.all { abs(it.second - mean) / mean < tol }) {
                learn(mean)
                lastLearnMs = now
            }
        }

        if (!ready) { candidate = null; return GearAdvice(null, null, gears.size, false) }

        val gearTol = 0.07 + 0.5 / speed
        val idx = gears.indexOfFirst { abs(ratio - it) / it < gearTol }
        if (idx < 0) { candidate = null; return GearAdvice(null, null, gears.size, true) } // pisando embrague o en punto muerto

        var target: Int? = null
        if (idx < gears.size - 1 && rpm >= config.upshiftRpm) {
            val rpmNext = speed * 1000.0 / gears[idx + 1]
            if (rpmNext >= config.minRpmAfterUp) target = idx + 1
        } else if (idx > 0 && rpm < config.luggingRpm && (load ?: 0) >= 60) {
            target = idx - 1
        }

        if (target != candidate) { candidate = target; candidateSince = now }
        val shown = if (target != null && now - candidateSince >= config.holdMs) target + 1 else null
        return GearAdvice(idx + 1, shown, gears.size, true)
    }

    private fun learn(r: Double) {
        val near = clusters.minByOrNull { abs(it.ratio - r) / it.ratio }
        if (near != null && abs(near.ratio - r) / near.ratio < 0.06) {
            val n = minOf(near.count, 200)
            near.ratio = (near.ratio * n + r) / (n + 1)
            near.count = n + 1
        } else {
            clusters += GearCluster(r, 1)
        }
        // Fusiona grupos que hayan convergido.
        clusters.sortBy { it.ratio }
        var i = 0
        while (i < clusters.size - 1) {
            val a = clusters[i]; val b = clusters[i + 1]
            if (abs(a.ratio - b.ratio) / a.ratio < 0.04) {
                val tot = a.count + b.count
                a.ratio = (a.ratio * a.count + b.ratio * b.count) / tot
                a.count = tot
                clusters.removeAt(i + 1)
            } else i++
        }
        // Limita el tamaño descartando grupos raros (ruido).
        if (clusters.size > 20) clusters.remove(clusters.minByOrNull { it.count })
        changed = true
    }

    /** Relaciones válidas ordenadas de 1ª a la última. */
    @Synchronized
    fun validGears(): List<Double> {
        val solid = clusters.filter { it.count >= 5 }
        val top = if (solid.size > config.gearCount) solid.sortedByDescending { it.count }.take(config.gearCount) else solid
        return top.map { it.ratio }.sorted()
    }

    @Synchronized
    fun export(): List<GearCluster> { changed = false; return clusters.map { it.copy() } }

    @Synchronized
    fun forget() { clusters.clear(); window.clear(); candidate = null; changed = true }

    companion object {
        fun serialize(list: List<GearCluster>): String = list.joinToString(";") { "${it.ratio}:${it.count}" }
        fun deserialize(s: String): List<GearCluster> = s.split(";").mapNotNull { part ->
            val p = part.split(":")
            val r = p.getOrNull(0)?.toDoubleOrNull()
            val c = p.getOrNull(1)?.toIntOrNull()
            if (r != null && c != null && r > 0) GearCluster(r, c) else null
        }
    }
}

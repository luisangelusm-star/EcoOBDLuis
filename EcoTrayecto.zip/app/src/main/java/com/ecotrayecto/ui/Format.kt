package com.ecotrayecto.ui

import com.ecotrayecto.data.AppSettings
import com.ecotrayecto.trip.TripStats
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ES = Locale("es", "ES")

fun fmtDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

fun fmtKm(km: Double): String = if (km < 10) String.format(ES, "%.2f", km) else String.format(ES, "%.1f", km)

fun fmtNum(v: Double, decimals: Int = 1): String = String.format(ES, "%.${decimals}f", v)

fun fmtEuro(v: Double): String = String.format(ES, "%.2f €", v)

fun fmtDate(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("d MMM, HH:mm", ES).format(Date(ms))

/** Litros ahorrados de verdad: el tiempo en corte habría sido, como mínimo, ralentí en punto muerto. */
fun savedLitersReal(t: TripStats, s: AppSettings): Double = t.ecoMs / 3_600_000.0 * s.idleConsumption

/** Estimación máxima: como si esos km se hubieran hecho con el consumo medio del coche. */
fun savedLitersMax(t: TripStats, s: AppSettings): Double = t.ecoKm * s.avgConsumption / 100.0

fun parseDecimal(text: String): Double? = text.trim().replace(',', '.').toDoubleOrNull()

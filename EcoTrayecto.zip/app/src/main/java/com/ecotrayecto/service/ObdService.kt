package com.ecotrayecto.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import com.ecotrayecto.MainActivity
import com.ecotrayecto.R
import com.ecotrayecto.data.AdapterType
import com.ecotrayecto.data.AppState
import com.ecotrayecto.data.ConnStatus
import com.ecotrayecto.data.DtcInfo
import com.ecotrayecto.data.DtcRequest
import com.ecotrayecto.data.LiveInfo
import com.ecotrayecto.obd.BleTransport
import com.ecotrayecto.obd.ClassicTransport
import com.ecotrayecto.obd.Elm327
import com.ecotrayecto.obd.ObdParser
import com.ecotrayecto.obd.ObdTransport
import com.ecotrayecto.trip.Sample
import com.ecotrayecto.trip.TripState
import com.ecotrayecto.ui.fmtDuration
import java.io.IOException

class ObdService : Service() {

    companion object {
        const val ACTION_STOP = "com.ecotrayecto.STOP"
        private const val CH_RUN = "trayecto"
        private const val CH_ALERT = "aviso_ralenti"
        private const val ID_RUN = 1
        private const val ID_ALERT = 2

        fun start(ctx: Context) {
            val i = Intent(ctx, ObdService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, ObdService::class.java).setAction(ACTION_STOP))
        }
    }

    @Volatile private var running = false
    private var worker: Thread? = null
    private var transport: ObdTransport? = null
    private var lastNotify = 0L
    private var lastPendingSave = 0L
    private var lastVoltage = 0L
    private var lastGearSave = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppState.init(this)
        createChannels()
        AppState.onIdleAlert = { showIdleAlert() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        val n = buildNotification("Conectando con el adaptador…")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(ID_RUN, n)
            }
        } catch (e: Exception) {
            AppState.live.set(LiveInfo(ConnStatus.ERROR, "Faltan permisos de Bluetooth o notificaciones"))
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            AppState.serviceRunning = true
            worker = Thread({ loop() }, "obd").also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        transport?.close()
        AppState.serviceRunning = false
        AppState.onIdleAlert = null
        super.onDestroy()
    }

    private fun stopEverything() {
        running = false
        transport?.close()
        worker?.interrupt()
        AppState.engine.forceFinish()
        AppState.publishTrip()
        AppState.saveGearsIfChanged()
        AppState.live.set(LiveInfo(ConnStatus.OFF, "Sin conectar"))
        AppState.serviceRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- bucle de lectura

    @SuppressLint("MissingPermission")
    private fun openTransport(): ObdTransport {
        val s = AppState.settings.value
        if (s.deviceAddress.isEmpty()) throw IOException("Elige tu adaptador en Ajustes")
        val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bm.adapter ?: throw IOException("Este móvil no tiene Bluetooth")
        if (!adapter.isEnabled) throw IOException("Activa el Bluetooth del móvil")
        val device = adapter.getRemoteDevice(s.deviceAddress)
        return if (s.adapterType == AdapterType.BLE) BleTransport(this, device) else ClassicTransport(device)
    }

    private fun loop() {
        while (running) {
            try {
                setLive { it.copy(status = ConnStatus.CONNECTING, message = "Conectando con ${AppState.settings.value.deviceName.ifEmpty { "el adaptador" }}…") }
                val t = openTransport()
                transport = t
                t.connect()
                val elm = Elm327(t)
                elm.initialize()
                runConnected(elm)
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                if (!running) break
                AppState.engine.onNoData(System.currentTimeMillis())
                AppState.publishTrip()
                setLive { it.copy(status = ConnStatus.ERROR, message = (e.message ?: "Error de conexión") + ". Reintentando…", speed = null, rpm = null, load = null) }
                transport?.close()
                sleepQuiet(3000)
            }
        }
    }

    private fun runConnected(elm: Elm327) {
        var detected = false
        var failures = 0
        var cycle = 0
        var coolant: Int? = null

        while (running) {
            val now = System.currentTimeMillis()

            if (!detected) {
                val v = elm.batteryVoltage()
                setLive { it.copy(status = ConnStatus.WAITING_CAR, message = "Adaptador listo. Esperando al coche (da el contacto)…", voltage = v ?: it.voltage, gear = null, gearSuggestion = null) }
                detected = elm.detectVehicle()
                if (!detected) {
                    AppState.engine.onNoData(System.currentTimeMillis())
                    AppState.publishTrip()
                    sleepQuiet(2000)
                    continue
                }
                failures = 0
                val method = when {
                    0x5E in elm.supported -> "Caudal de combustible (PID 5E)"
                    0x04 in elm.supported && 0x0C in elm.supported -> "Carga del motor + rpm"
                    else -> "No disponible en este coche"
                }
                setLive { it.copy(status = ConnStatus.CONNECTED, message = "Conectado", protocol = elm.protocolName, ecoMethod = method, speedMode = elm.speedMode) }
            }

            handleDtcRequest(elm)

            val pids = buildList {
                add(0x0D)
                if (elm.has(0x0C)) add(0x0C)
                if (elm.has(0x04)) add(0x04)
                if (0x5E in elm.supported) add(0x5E)
            }
            val data = elm.readMany(pids)
            val speedData = data[0x0D]
            if (speedData == null) {
                failures++
                AppState.engine.onNoData(System.currentTimeMillis())
                if (failures >= 8) {
                    detected = false // coche apagado: volvemos a esperar
                    setLive { it.copy(speed = null, rpm = null, load = null, gear = null, gearSuggestion = null) }
                }
                AppState.publishTrip()
                sleepQuiet(300)
                continue
            }
            failures = 0

            val speed = ObdParser.speedKmh(speedData) ?: 0
            val rpm = data[0x0C]?.let { ObdParser.rpm(it) }
            val load = data[0x04]?.let { ObdParser.loadPct(it) }
            val fuel = data[0x5E]?.let { ObdParser.fuelRateLh(it) }
            if (cycle % 20 == 0 && elm.has(0x05)) coolant = elm.pid(0x05)?.let { ObdParser.coolantC(it) } ?: coolant
            cycle++

            val t = System.currentTimeMillis()
            AppState.engine.onSample(t, Sample(speed, rpm, load, coolant, fuel))
            AppState.publishTrip()
            val advice = AppState.gears.onSample(t, speed, rpm, load)

            var voltage = AppState.live.value.voltage
            if (t - lastVoltage > 10_000) { lastVoltage = t; voltage = elm.batteryVoltage() ?: voltage }

            setLive {
                it.copy(
                    status = ConnStatus.CONNECTED, message = "Conectado", speed = speed, rpm = rpm, load = load,
                    coolant = coolant, fuelRate = fuel, voltage = voltage, speedMode = elm.speedMode,
                    gear = advice.gear, gearSuggestion = advice.suggestion, gearsLearned = advice.learned,
                )
            }
            if (t - lastGearSave > 60_000) { lastGearSave = t; AppState.saveGearsIfChanged() }

            savePendingAndNotify(now)

            val elapsed = System.currentTimeMillis() - now
            if (elapsed < 250) sleepQuiet(250 - elapsed)
        }
    }

    private fun handleDtcRequest(elm: Elm327) {
        val req = AppState.dtcRequest ?: return
        AppState.dtcRequest = null
        AppState.dtc.set(AppState.dtc.value.copy(busy = true, message = "Consultando la centralita…"))
        try {
            when (req) {
                DtcRequest.READ -> {
                    val stored = elm.readDtcs(false)
                    val pending = elm.readDtcs(true)
                    val msg = if (stored.isEmpty() && pending.isEmpty()) "Sin averías registradas" else "Lectura completada"
                    AppState.dtc.set(DtcInfo(false, stored, pending, msg))
                }
                DtcRequest.CLEAR -> {
                    val ok = elm.clearDtcs()
                    val stored = elm.readDtcs(false)
                    AppState.dtc.set(DtcInfo(false, stored, elm.readDtcs(true),
                        if (ok) "Averías borradas. Si vuelven a aparecer, el fallo sigue presente." else "La centralita no confirmó el borrado"))
                }
            }
        } catch (e: IOException) {
            AppState.dtc.set(AppState.dtc.value.copy(busy = false, message = "Error de comunicación al leer averías"))
            throw e
        }
    }

    private fun savePendingAndNotify(now: Long) {
        if (now - lastPendingSave > 30_000) {
            lastPendingSave = now
            AppState.storage.savePending(AppState.engine.runningTrip())
        }
        if (now - lastNotify > 5_000) {
            lastNotify = now
            val snap = AppState.trip.value
            val text = when (snap.state) {
                TripState.WAITING -> "Esperando a superar 5 km/h"
                TripState.FINISHED -> "Viaje finalizado: ${fmtDuration(snap.trip.totalMs)}"
                TripState.RUNNING -> "En marcha ${fmtDuration(snap.trip.movingMs)} · Parado ${fmtDuration(snap.trip.stoppedMs)} (${snap.trip.stoppedPct()} %)"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(ID_RUN, buildNotification(text))
        }
    }

    private inline fun setLive(f: (LiveInfo) -> LiveInfo) = AppState.live.set(f(AppState.live.value))

    private fun sleepQuiet(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { }
    }

    // ---------------------------------------------------------------- notificaciones

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Trayecto en curso", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Aviso de ralentí", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ObdService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH_RUN) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(R.drawable.ic_leaf)
            .setContentTitle("EcoTrayecto")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(Notification.Action.Builder(null, "Desconectar", stop).build())
            .build()
    }

    private fun showIdleAlert() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val mins = AppState.settings.value.idleAlertMin
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH_ALERT) else @Suppress("DEPRECATION") Notification.Builder(this)
        nm.notify(ID_ALERT, b.setSmallIcon(R.drawable.ic_leaf)
            .setContentTitle("Motor al ralentí")
            .setContentText("Llevas $mins min parado con el motor en marcha.")
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build())
        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 300), -1))
        } catch (_: Exception) { }
    }
}

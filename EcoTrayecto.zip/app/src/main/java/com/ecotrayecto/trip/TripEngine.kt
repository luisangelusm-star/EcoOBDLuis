package com.ecotrayecto.trip

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Una lectura válida del coche. Los campos opcionales son null si el coche no los soporta. */
data class Sample(
    val speedKmh: Int,
    val rpm: Int?,
    val loadPct: Int?,
    val coolantC: Int?,
    val fuelRateLh: Double?,
)

data class EngineConfig(
    val startSpeedKmh: Int = 5,        // el viaje empieza al superar esta velocidad
    val stopSpeedKmh: Int = 2,         // por debajo de esto se considera parado
    val endTimeoutMs: Long = 10_000,   // sin comunicación más de esto = contacto quitado
    val gapAsStoppedMs: Long = 3_000,  // huecos de comunicación mayores se cuentan como parado
    val ecoMinSpeedKmh: Int = 15,
    val ecoMinRpm: Int = 1100,
    val ecoMaxLoadPct: Int = 2,
    val ecoMinCoolantC: Int = 60,
    val idleAlertMs: Long = 120_000,   // 0 = aviso desactivado
    val longIdleMs: Long = 60_000,     // a partir de aquí el ralentí penaliza la puntuación
)

data class TripStats(
    var movingMs: Long = 0,
    var stoppedMs: Long = 0,
    var distanceM: Double = 0.0,
    var ecoMs: Long = 0,
    var ecoDistanceM: Double = 0.0,
    var idleMs: Long = 0,
    var longIdleMs: Long = 0,
    var harshAccel: Int = 0,
    var harshBrake: Int = 0,
    var trips: Int = 0,
    var startTime: Long = 0,
    var endTime: Long = 0,
) {
    val totalMs: Long get() = movingMs + stoppedMs
    val distanceKm: Double get() = distanceM / 1000.0
    val ecoKm: Double get() = ecoDistanceM / 1000.0

    fun stoppedPct(): Int = if (totalMs <= 0) 0 else (stoppedMs * 100.0 / totalMs).roundToInt()
    fun ecoDistancePct(): Int = if (distanceM <= 0.0) 0 else (ecoDistanceM * 100.0 / distanceM).roundToInt()

    /** Velocidad media contando todo el tiempo (también el parado). */
    fun avgSpeedKmh(): Double = if (totalMs <= 0) 0.0 else distanceKm / (totalMs / 3_600_000.0)

    /** Velocidad media solo con el tiempo en marcha. */
    fun movingAvgSpeedKmh(): Double = if (movingMs <= 0) 0.0 else distanceKm / (movingMs / 3_600_000.0)

    /** Puntuación 0-100, o -1 si el recorrido es demasiado corto para valorarlo. */
    fun ecoScore(): Int {
        val km = distanceKm
        if (km < 0.3) return -1
        val ecoRatio = ecoDistanceM / distanceM
        val harshPer10km = (harshAccel + harshBrake) / max(km, 2.0) * 10.0
        val harshPenalty = min(40.0, harshPer10km * 5.0)
        val idlePenalty = min(20.0, longIdleMs / 60_000.0 * 2.0)
        val score = 70.0 + min(30.0, ecoRatio * 150.0) - harshPenalty - idlePenalty
        return score.roundToInt().coerceIn(0, 100)
    }

    fun add(o: TripStats) {
        movingMs += o.movingMs; stoppedMs += o.stoppedMs; distanceM += o.distanceM
        ecoMs += o.ecoMs; ecoDistanceM += o.ecoDistanceM; idleMs += o.idleMs
        longIdleMs += o.longIdleMs; harshAccel += o.harshAccel; harshBrake += o.harshBrake
        trips += o.trips
    }
}

enum class TripState { WAITING, RUNNING, FINISHED }

interface TripListener {
    fun onTripFinished(trip: TripStats)
    fun onIdleAlert()
}

data class EngineSnapshot(
    val state: TripState,
    val moving: Boolean,
    val ecoActive: Boolean,
    val idleAlert: Boolean,
    val trip: TripStats,
    val totals: TripStats,
)

/**
 * Lógica del trayecto. No depende de Android para poder probarla.
 * - El viaje empieza al superar startSpeedKmh.
 * - Alterna entre En marcha / Parado según la velocidad.
 * - Huecos cortos de comunicación (calado y rearranque) cuentan como parado.
 * - Más de endTimeoutMs sin comunicación = contacto quitado: el viaje se congela y se suma al total.
 * - El viaje congelado se borra al volver a circular, con el botón o al reiniciar la app.
 */
class TripEngine(
    config: EngineConfig,
    initialTotals: TripStats,
    private val listener: TripListener?,
) {
    @Volatile var config: EngineConfig = config

    private var state = TripState.WAITING
    private var trip = TripStats()
    private var savedTotals = initialTotals.copy()

    private var lastValidMs = 0L
    private var lastSample: Sample? = null
    private var moving = false
    private var ecoActive = false

    private var idleStartMs = -1L
    private var idleAlertFired = false
    private var idleAlertActive = false

    private var accelRefMs = -1L
    private var accelRefSpeed = 0
    private var lastHarshMs = -100_000L

    @Synchronized
    fun onSample(now: Long, s: Sample) {
        when (state) {
            TripState.WAITING, TripState.FINISHED -> {
                if (s.speedKmh > config.startSpeedKmh) {
                    trip = TripStats(trips = 1, startTime = now)
                    state = TripState.RUNNING
                    moving = true
                    resetTracking()
                    accelRefMs = now; accelRefSpeed = s.speedKmh
                }
            }
            TripState.RUNNING -> processRunning(now, s)
        }
        lastValidMs = now
        lastSample = s
    }

    private fun processRunning(now: Long, s: Sample) {
        val dt = (now - lastValidMs).coerceAtLeast(0)
        val prev = lastSample
        moving = s.speedKmh >= config.stopSpeedKmh

        if (dt > config.gapAsStoppedMs) {
            // Hueco de comunicación (p. ej. calado y rearranque): cuenta como parado.
            trip.stoppedMs += dt
            ecoActive = false
            idleStartMs = -1
            accelRefMs = now; accelRefSpeed = s.speedKmh
            return
        }

        val avgSpeed = if (prev != null) (prev.speedKmh + s.speedKmh) / 2.0 else s.speedKmh.toDouble()
        val d = avgSpeed / 3.6 * dt / 1000.0
        trip.distanceM += d
        if (moving) trip.movingMs += dt else trip.stoppedMs += dt

        ecoActive = isFuelCut(s)
        if (ecoActive) {
            trip.ecoMs += dt
            trip.ecoDistanceM += d
        }

        // Ralentí: parado con el motor girando (con Start-Stop las rpm caen a 0 y no cuenta).
        val engineRunning = (s.rpm ?: 800) > 300
        if (!moving && engineRunning) {
            trip.idleMs += dt
            if (idleStartMs < 0) idleStartMs = now
            val idleFor = now - idleStartMs
            if (idleFor > config.longIdleMs) trip.longIdleMs += dt
            if (config.idleAlertMs > 0 && idleFor >= config.idleAlertMs && !idleAlertFired) {
                idleAlertFired = true
                idleAlertActive = true
                listener?.onIdleAlert()
            }
        } else {
            idleStartMs = -1
            idleAlertFired = false
            idleAlertActive = false
        }

        // Aceleraciones y frenadas bruscas, medidas en ventanas de ~1 s.
        if (accelRefMs < 0) { accelRefMs = now; accelRefSpeed = s.speedKmh }
        val win = now - accelRefMs
        if (win >= 1000) {
            if (win <= 2500) {
                val a = (s.speedKmh - accelRefSpeed) / 3.6 / (win / 1000.0)
                if (now - lastHarshMs > 3000) {
                    if (a > 2.5) { trip.harshAccel++; lastHarshMs = now }
                    else if (a < -3.0) { trip.harshBrake++; lastHarshMs = now }
                }
            }
            accelRefMs = now; accelRefSpeed = s.speedKmh
        }
    }

    private fun isFuelCut(s: Sample): Boolean {
        if (s.speedKmh < config.ecoMinSpeedKmh) return false
        val coolant = s.coolantC
        if (coolant != null && coolant < config.ecoMinCoolantC) return false
        val fuel = s.fuelRateLh
        if (fuel != null) return fuel < 0.05
        val rpm = s.rpm ?: return false
        val load = s.loadPct ?: return false
        return rpm >= config.ecoMinRpm && load <= config.ecoMaxLoadPct
    }

    /** Llamar cuando una petición falla o periódicamente si no hay conexión. */
    @Synchronized
    fun onNoData(now: Long) {
        ecoActive = false
        if (state == TripState.RUNNING && now - lastValidMs > config.endTimeoutMs) finish()
    }

    /** Desconexión manual: cierra el viaje como si se hubiera quitado el contacto. */
    @Synchronized
    fun forceFinish() {
        if (state == TripState.RUNNING) finish()
    }

    private fun finish() {
        trip.endTime = lastValidMs
        savedTotals.add(trip)
        state = TripState.FINISHED
        moving = false
        resetTracking()
        listener?.onTripFinished(trip.copy())
    }

    private fun resetTracking() {
        ecoActive = false
        idleStartMs = -1
        idleAlertFired = false
        idleAlertActive = false
        accelRefMs = -1
    }

    /** Botón de reset del viaje. Si estaba en curso, lo que llevaba se guarda en el total. */
    @Synchronized
    fun resetTrip(now: Long): TripStats? {
        var closed: TripStats? = null
        if (state == TripState.RUNNING) {
            trip.endTime = now
            savedTotals.add(trip)
            closed = trip.copy()
        }
        trip = TripStats()
        state = TripState.WAITING
        moving = false
        resetTracking()
        return closed
    }

    @Synchronized
    fun resetTotals() { savedTotals = TripStats() }

    @Synchronized
    fun dismissIdleAlert() { idleAlertActive = false }

    @Synchronized
    fun savedTotals(): TripStats = savedTotals.copy()

    /** Viaje en curso (para guardarlo por si la app se cierra de golpe), o null. */
    @Synchronized
    fun runningTrip(): TripStats? = if (state == TripState.RUNNING) trip.copy() else null

    @Synchronized
    fun snapshot(): EngineSnapshot {
        val totals = savedTotals.copy()
        if (state == TripState.RUNNING) totals.add(trip)
        return EngineSnapshot(state, moving, ecoActive, idleAlertActive, trip.copy(), totals)
    }
}

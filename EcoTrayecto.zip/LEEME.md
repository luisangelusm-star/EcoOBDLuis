# EcoTrayecto

App Android que lee el coche con un ELM327 (Bluetooth clásico o BLE) y mide el tiempo en marcha frente al tiempo parado, los km, los km recorridos sin consumir combustible (corte de inyección), la puntuación eco y las averías.

## Opción A: compilar en GitHub (sin instalar nada)

1. Crea una cuenta en github.com y un repositorio nuevo (por ejemplo `ecotrayecto`), privado si quieres.
2. En el repositorio pulsa **Add file > Upload files** y arrastra **todo el contenido** de esta carpeta (no la carpeta en sí). Pulsa **Commit changes**.
3. Comprueba que se ha subido la carpeta `.github/workflows/build.yml`. Algunos navegadores ocultan las carpetas que empiezan por punto: si no aparece, crea el archivo a mano con **Add file > Create new file**, escribe `.github/workflows/build.yml` como nombre y pega su contenido.
4. Ve a la pestaña **Actions**. Verás "Compilar APK" en marcha (tarda unos 5 minutos la primera vez).
5. Cuando termine en verde, entra en la ejecución y descarga **EcoTrayecto-apk** (abajo, en Artifacts). Es un .zip con el .apk dentro.
6. Pasa el .apk al móvil, ábrelo y permite instalar apps de origen desconocido cuando lo pida.

Si sale en rojo, abre el paso "Compilar", copia las líneas del error y pásamelas.

## Opción B: Android Studio

Abre esta carpeta con **File > Open**, espera a que termine de sincronizar y pulsa **Run** con el móvil conectado por USB (con la depuración USB activada), o **Build > Build APK(s)**.

## Primer uso

1. Si tu adaptador es Bluetooth clásico, emparéjalo antes desde los ajustes de Bluetooth del móvil (PIN 1234 o 0000).
2. Abre la app y concede los permisos de Bluetooth y notificaciones.
3. En **Ajustes** elige el tipo de adaptador y pulsa **Elegir adaptador**.
4. Rellena marca, combustible, precio y consumos.
5. En **Panel** pulsa **Conectar**. Con el contacto dado, el estado pasa a "Conectado".
6. Haz la prueba de **Calibración** (en Ajustes) la primera vez para ajustar la detección sin consumo a tu coche.

## Cómo funciona el viaje

- Empieza al superar 5 km/h. Por debajo de 2 km/h cuenta como parado.
- Con Start-Stop o si se cala sin perder comunicación, el viaje sigue.
- Si se pierde la comunicación menos de 10 s (configurable), el viaje sigue y ese hueco cuenta como parado.
- Más de 10 s sin comunicación = contacto quitado: el viaje se congela, se suma al total y se guarda en el historial.
- El viaje congelado se borra al volver a circular, al cerrar y abrir la app o con el botón.

## Marcha recomendada

Las relaciones de cambio se aprenden solas: circula unos segundos a ritmo constante en cada marcha. Hasta que estén todas, el panel muestra "Aprendiendo marchas". Indica el número de marchas de tu coche en Ajustes.

## Velocidad de lectura

La app prueba la petición múltiple (varios datos en una consulta, solo CAN) y la respuesta inmediata del ELM327. Si tu adaptador no las admite, vuelve sola al método normal. En Ajustes > Calibración puedes ver qué modo está usando.

## Tensión de batería

Se ve en la esquina superior derecha. En ocre o rojo si está baja con el motor parado, o por debajo de 13 V con el motor en marcha (posible fallo de carga).

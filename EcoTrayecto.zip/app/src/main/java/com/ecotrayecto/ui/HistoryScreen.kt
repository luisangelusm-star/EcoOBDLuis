package com.ecotrayecto.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ecotrayecto.data.AppState
import com.ecotrayecto.trip.TripStats

@Composable
fun HistoryScreen() {
    val history by AppState.history.asState()
    val settings by AppState.settings.asState()
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    val recent = history.take(12).reversed() // más antiguo a la izquierda

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Spacer(Modifier.height(8.dp)); Text("Historial", style = TitleStyle) }

        if (history.isEmpty()) {
            item {
                Text(
                    "Todavía no hay viajes. Cada trayecto se guarda aquí al quitar el contacto o al reiniciar el viaje.",
                    style = BodyStyle.copy(color = Eco.Dim),
                )
            }
            return@LazyColumn
        }

        item {
            ChartCard("Tiempo parado en los últimos viajes") {
                StoppedBars(recent, Modifier.fillMaxWidth().height(170.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    LegendDot(Eco.Leaf, "En marcha"); LegendDot(Eco.Ochre, "Parado")
                }
            }
        }

        val scored = recent.map { it.ecoScore() }.filter { it >= 0 }
        if (scored.size >= 2) {
            item {
                ChartCard("Evolución de la puntuación eco") {
                    ScoreLine(scored, Modifier.fillMaxWidth().height(140.dp))
                }
            }
        }

        item { Text("Viajes", style = TitleStyle.copy(fontSize = 18.sp)) }

        items(history) { t -> TripRow(t, settings.fuelPrice * settings.idleConsumption) }

        item {
            TextButton({ confirmClear = true }, Modifier.fillMaxWidth()) { Text("Borrar historial", color = Eco.Danger) }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Eco.Surface, titleContentColor = Eco.Lichen, textContentColor = Eco.Dim,
            title = { Text("¿Borrar el historial?") },
            text = { Text("Se eliminarán todos los viajes guardados. Los totales acumulados no cambian.") },
            confirmButton = { TextButton({ AppState.clearHistory(); confirmClear = false }) { Text("Borrar", color = Eco.Danger) } },
            dismissButton = { TextButton({ confirmClear = false }) { Text("Cancelar", color = Eco.Lichen) } },
        )
    }
}

@Composable
private fun ChartCard(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eco.Surface).padding(16.dp)) {
        Text(title, style = BodyStyle)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun LegendDot(color: androidx.compose.ui.graphics.Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(12.dp).height(12.dp).clip(RoundedCornerShape(6.dp)).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = LabelStyle)
    }
}

/** Barras apiladas: abajo tiempo en marcha, arriba tiempo parado, con el % encima. */
@Composable
private fun StoppedBars(trips: List<TripStats>, modifier: Modifier) {
    Canvas(modifier) {
        if (trips.isEmpty()) return@Canvas
        val textPx = 11.dp.toPx()
        val paint = Paint().apply { color = Eco.Dim.toArgb(); textSize = textPx; textAlign = Paint.Align.CENTER; isAntiAlias = true }
        val top = textPx + 6.dp.toPx()
        val chartH = size.height - top
        val slot = size.width / trips.size
        val barW = slot * 0.6f
        val r = CornerRadius(4.dp.toPx())
        trips.forEachIndexed { i, t ->
            val x = i * slot + (slot - barW) / 2
            val total = t.totalMs.coerceAtLeast(1)
            val stoppedH = chartH * t.stoppedMs / total
            drawRoundRect(Eco.Leaf, Offset(x, top), Size(barW, chartH), r)
            if (stoppedH > 0) drawRoundRect(Eco.Ochre, Offset(x, top), Size(barW, stoppedH), r)
            drawIntoCanvas { it.nativeCanvas.drawText("${t.stoppedPct()}", x + barW / 2, textPx, paint) }
        }
    }
}

@Composable
private fun ScoreLine(scores: List<Int>, modifier: Modifier) {
    Canvas(modifier) {
        val pad = 8.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        listOf(50, 75).forEach { level ->
            val y = pad + h * (1 - level / 100f)
            drawLine(Eco.Line, Offset(pad, y), Offset(size.width - pad, y), strokeWidth = 1.dp.toPx())
        }
        val step = if (scores.size > 1) w / (scores.size - 1) else 0f
        val path = Path()
        scores.forEachIndexed { i, s ->
            val p = Offset(pad + i * step, pad + h * (1 - s / 100f))
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        drawPath(path, Eco.Teal, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        scores.forEachIndexed { i, s ->
            drawCircle(Eco.Teal, 4.dp.toPx(), Offset(pad + i * step, pad + h * (1 - s / 100f)))
        }
    }
}

@Composable
private fun TripRow(t: TripStats, eurPerHourEco: Double) {
    val score = t.ecoScore()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Eco.Surface).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtDate(t.startTime), style = BodyStyle, modifier = Modifier.weight(1f))
            Text(if (score < 0) "—" else "$score", style = numberStyle(24), color = Eco.Teal)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "${fmtDuration(t.totalMs)}   ${fmtKm(t.distanceKm)} km   ${t.stoppedPct()} % parado   ${fmtKm(t.ecoKm)} km sin consumir",
            style = LabelStyle,
        )
        Spacer(Modifier.height(8.dp))
        val frac = if (t.totalMs > 0) t.movingMs.toFloat() / t.totalMs else 0f
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Eco.Ochre)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Eco.Leaf))
        }
        val saved = t.ecoMs / 3_600_000.0 * eurPerHourEco
        if (saved >= 0.01) {
            Spacer(Modifier.height(6.dp))
            Text("Ahorro ${fmtEuro(saved)}", style = LabelStyle.copy(color = Eco.Teal))
        }
    }
}

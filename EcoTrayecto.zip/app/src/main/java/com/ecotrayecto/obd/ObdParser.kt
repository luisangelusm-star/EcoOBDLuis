package com.ecotrayecto.obd

/** Funciones puras para interpretar las respuestas del ELM327 (sin Android, para poder probarlas). */
object ObdParser {

    private val ERRORS = listOf(
        "NODATA", "UNABLETOCONNECT", "CANERROR", "BUSERROR", "BUSBUSY", "BUSINIT...ERROR",
        "FBERROR", "DATAERROR", "STOPPED", "ERROR", "TIMEOUT", "<RXERROR", "BUFFERFULL",
    )

    /** Líneas limpias: sin espacios, sin "SEARCHING...", en mayúsculas. */
    fun cleanLines(raw: String): List<String> =
        raw.uppercase()
            .split('\r', '\n')
            .map { it.replace(" ", "").replace("\u0000", "").replace("SEARCHING...", "").trim() }
            .filter { it.isNotEmpty() }

    fun isError(raw: String): Boolean {
        val joined = raw.uppercase().replace(" ", "").replace("\r", "").replace("\n", "")
        if (joined.isEmpty() || joined == "?") return true
        return ERRORS.any { joined.contains(it) }
    }

    /** Bytes de datos de la respuesta a "01xx" (sin el 41 xx), o null. */
    fun pidData(raw: String, pid: Int): IntArray? {
        if (isError(raw)) return null
        val header = "41" + "%02X".format(pid)
        for (line in cleanLines(raw)) {
            val idx = line.indexOf(header)
            if (idx < 0) continue
            val data = line.substring(idx + header.length)
            if (data.length < 2 || !data.all { it.isHexDigitChar() }) continue
            return hexToBytes(data)
        }
        return null
    }

    /** PIDs soportados a partir de la respuesta de 0100 / 0120 / 0140. */
    fun supportedPids(data: IntArray, base: Int): Set<Int> {
        val out = HashSet<Int>()
        for (i in 0 until minOf(4, data.size)) {
            for (bit in 0 until 8) {
                if (data[i] and (0x80 shr bit) != 0) out.add(base + i * 8 + bit + 1)
            }
        }
        return out
    }

    fun speedKmh(d: IntArray): Int? = d.getOrNull(0)
    fun rpm(d: IntArray): Int? = if (d.size >= 2) (d[0] * 256 + d[1]) / 4 else null
    fun loadPct(d: IntArray): Int? = d.getOrNull(0)?.let { Math.round(it * 100f / 255f) }
    fun coolantC(d: IntArray): Int? = d.getOrNull(0)?.let { it - 40 }
    fun fuelRateLh(d: IntArray): Double? = if (d.size >= 2) (d[0] * 256 + d[1]) / 20.0 else null

    /** ATDPN devuelve p. ej. "A6" o "6". Protocolos 6-9 y A-C son CAN. */
    fun isCanProtocol(dpn: String): Boolean {
        val c = dpn.uppercase().trim().removePrefix("A").firstOrNull() ?: return true
        return c in "6789ABC"
    }

    fun protocolName(dpn: String): String {
        val c = dpn.uppercase().trim().let { if (it.length == 2 && it[0] == 'A') it.substring(1) else it }
        return when (c.firstOrNull()) {
            '1' -> "SAE J1850 PWM"
            '2' -> "SAE J1850 VPW"
            '3' -> "ISO 9141-2 (K-Line)"
            '4' -> "KWP2000 5 baudios (K-Line)"
            '5' -> "KWP2000 rápido (K-Line)"
            '6', '7', '8', '9' -> "CAN (ISO 15765-4)"
            'A' -> "SAE J1939 (CAN)"
            else -> "Desconocido"
        }
    }

    /**
     * Códigos de avería de la respuesta a 03 (header "43") o 07 (header "47").
     * Soporta CAN (con byte de recuento y tramas múltiples "0:", "1:"...) y K-Line.
     */
    fun parseDtcs(raw: String, header: String, isCan: Boolean): List<String> {
        if (isError(raw)) return emptyList()
        val lines = cleanLines(raw)
        val chunks = mutableListOf<String>()

        val multiFrame = lines.any { it.length > 2 && it[1] == ':' && it[0].isHexDigitChar() }
        if (multiFrame) {
            val sb = StringBuilder()
            for (l in lines) {
                val colon = l.indexOf(':')
                if (colon == 1) sb.append(l.substring(2))
            }
            chunks.add(sb.toString())
        } else {
            chunks.addAll(lines)
        }

        val result = LinkedHashSet<String>()
        for (chunk in chunks) {
            if (!chunk.startsWith(header)) continue
            var data = chunk.substring(header.length)
            if (isCan && data.length >= 2) data = data.substring(2) // byte de recuento
            var i = 0
            while (i + 4 <= data.length) {
                val code = data.substring(i, i + 4)
                i += 4
                if (code == "0000" || !code.all { it.isHexDigitChar() }) continue
                result.add(decodeDtc(code))
            }
        }
        return result.toList()
    }

    private val PID_LEN = mapOf(0x04 to 1, 0x05 to 1, 0x0C to 2, 0x0D to 1, 0x10 to 2, 0x11 to 1, 0x5E to 2)

    /**
     * Mensajes completos de la respuesta: una cadena hex por mensaje.
     * Une las tramas múltiples de CAN ("00B", "0:...", "1:...") y recorta el relleno final.
     */
    fun messages(raw: String): List<String> {
        val lines = cleanLines(raw)
        val multi = lines.any { it.length > 2 && it[1] == ':' }
        if (!multi) return lines.filter { l -> l.all { it in '0'..'9' || it in 'A'..'F' } }
        var len = -1
        val sb = StringBuilder()
        for (l in lines) {
            if (l.length > 2 && l[1] == ':') sb.append(l.substring(2))
            else if (l.length == 3 && l.all { it in '0'..'9' || it in 'A'..'F' }) len = l.toInt(16)
        }
        val data = sb.toString()
        return listOf(if (len > 0 && data.length >= len * 2) data.substring(0, len * 2) else data)
    }

    /**
     * Respuesta a una petición múltiple, p. ej. "010C0D04".
     * Devuelve null si el formato no es el esperado (adaptador que no lo soporta).
     */
    fun parseMultiPid(raw: String, pids: List<Int>): Map<Int, IntArray>? {
        if (isError(raw)) return null
        val msg = messages(raw).firstOrNull { it.startsWith("41") } ?: return null
        val out = HashMap<Int, IntArray>()
        var i = 2
        while (i + 2 <= msg.length) {
            val pid = msg.substring(i, i + 2).toInt(16)
            val n = PID_LEN[pid] ?: break
            if (pid !in pids || i + 2 + n * 2 > msg.length) break
            out[pid] = hexToBytes(msg.substring(i + 2, i + 2 + n * 2))
            i += 2 + n * 2
        }
        return if (out.keys.containsAll(pids)) out else null
    }

    /** "12.6V" -> 12.6 */
    fun voltage(raw: String): Double? =
        Regex("(\\d{1,2}[.,]\\d)").find(raw)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()

    /** "0133" -> "P0133", "C123" -> "U0123"... */
    fun decodeDtc(hex4: String): String {
        val first = hex4[0].digitToInt(16)
        val system = "PCBU"[first shr 2]
        val second = first and 0x3
        return "$system$second${hex4.substring(1)}"
    }

    fun hexToBytes(hex: String): IntArray {
        val n = hex.length / 2
        return IntArray(n) { hex.substring(it * 2, it * 2 + 2).toInt(16) }
    }

    private fun Char.isHexDigitChar(): Boolean = this in '0'..'9' || this in 'A'..'F'
}

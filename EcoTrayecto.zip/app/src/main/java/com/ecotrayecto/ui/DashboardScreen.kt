package com.ecotrayecto.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ecotrayecto.data.AppSettings
import com.ecotrayecto.data.AppState
import com.ecotrayecto.data.ConnStatus
import com.ecotrayecto.service.ObdService
import com.ecotrayecto.trip.EngineSnapshot
import com.ecotrayecto.trip.TripState
import com.ecotrayecto.trip.TripStats
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val PAGES = 5

@Composable
fun DashboardScreen(onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val snap by AppState.trip.asState()
    val live by AppState.live.asState()
    val settings by AppState.settings.asState()
    var showTotal by rememberSaveable { mutableStateOf(false) }
    var confirmTotalReset by rememberSaveable { mutableStateOf(false) }
    var notice by rememberSaveable { mutableStateOf("") }
    val pager = rememberPagerState(pageCount = { PAGES })
    val scope = rememberCoroutineScope()

    LaunchedEffect(settings.autoRotate, settings.rotateSeconds) {
        if (!settings.autoRotate) return@LaunchedEffect
        while (true) {
            delay(settings.rotateSeconds * 1000L)
            if (!pager.isScrollInProgress) pager.animateScrollToPage((pager.currentPage + 1) % PAGES)
        }
    }

    val stats = if (showTotal) snap.totals else snap.trip
    val running = live.status != ConnStatus.OFF

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
        // Conexión
        Row(verticalAlignment = Alignment.CenterVertically) {
            val dot = when (live.status) {
                ConnStatus.CONNECTED -> Eco.Leaf
                ConnStatus.WAITING_CAR, ConnStatus.CONNECTING -> Eco.Ochre
                ConnStatus.ERROR -> Eco.Danger
                ConnStatus.OFF -> Eco.Dim
            }
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
            Text(live.message, style = LabelStyle, modifier = Modifier.weight(1f), maxLines = 2)
            if (running) {
                TextButton({ ObdService.stop(context) }) { Text("Desconectar", color = Eco.Dim) }
            } else {
                Button(
                    onClick = {
                        if (settings.deviceAddress.isEmpty()) { notice = "Elige primero tu adaptador en Ajustes."; onOpenSettings() }
                        else { notice = ""; ObdService.start(context) }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Eco.Leaf, contentColor = Eco.Pine),
                ) { Text("Conectar") }
            }
        }
        if (notice.isNotEmpty()) Text(notice, style = LabelStyle.copy(color = Eco.Ochre))

        Spacer(Modifier.height(12.dp))

        // Viaje / Total
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Eco.Surface)) {
            SegmentButton("Viaje", !showTotal, Modifier.weight(1f)) { showTotal = false }
            SegmentButton("Total", showTotal, Modifier.weight(1f)) { showTotal = true }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(statusLine(snap, showTotal), style = BodyStyle.copy(color = statusColor(snap, showTotal)), modifier = Modifier.weight(1f))
            if (settings.gearAdvice && live.status == ConnStatus.CONNECTED) {
                GearBadge(live.gear, live.gearSuggestion, live.gearsLearned, settings.gearCount)
            }
        }

        if (snap.idleAlert && !showTotal) {
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Eco.Ochre).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Llevas ${settings.idleAlertMin} min al ralentí. Apagar el motor ahorra combustible.",
                    color = Eco.Pine, fontSize = 15.sp, modifier = Modifier.weight(1f))
                TextButton({ AppState.dismissIdleAlert() }) { Text("Entendido", color = Eco.Pine, fontWeight = FontWeight.Bold) }
            }
        }

        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            Box(Modifier.fillMaxSize().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                when (page) {
                    0 -> TimesPage(stats, snap, showTotal)
                    1 -> SplitPage(stats)
                    2 -> DistancePage(stats)
                    3 -> EcoPage(stats, snap, showTotal, settings)
                    else -> ScorePage(stats)
                }
            }
        }

        // Indicador de página (pulsable)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(PAGES) { i ->
                Box(
                    Modifier.padding(5.dp).size(if (i == pager.currentPage) 10.dp else 8.dp).clip(CircleShape)
                        .background(if (i == pager.currentPage) Eco.Lichen else Eco.Line)
                        .clickable { scope.launch { pager.animateScrollToPage(i) } },
                )
            }
        }

        Spacer(Modifier.height(6.dp))
        if (live.speed != null) {
            Text(
                listOfNotNull(
                    "${live.speed} km/h",
                    live.rpm?.let { "$it rpm" },
                    live.load?.let { "carga $it %" },
                    live.coolant?.let { "$it °C" },
                ).joinToString("   "),
                style = LabelStyle, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
        }

        OutlinedButton(
            onClick = { if (showTotal) confirmTotalReset = true else AppState.resetTrip() },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (showTotal) "Reiniciar total" else "Reiniciar viaje", color = Eco.Lichen) }
    }

    if (confirmTotalReset) {
        AlertDialog(
            onDismissRequest = { confirmTotalReset = false },
            containerColor = Eco.Surface, titleContentColor = Eco.Lichen, textContentColor = Eco.Dim,
            title = { Text("¿Reiniciar el total?") },
            text = { Text("Se pondrán a cero todos los tiempos, kilómetros y ahorros acumulados. El historial de viajes se conserva.") },
            confirmButton = { TextButton({ AppState.resetTotals(); confirmTotalReset = false }) { Text("Reiniciar", color = Eco.Danger) } },
            dismissButton = { TextButton({ confirmTotalReset = false }) { Text("Cancelar", color = Eco.Lichen) } },
        )
    }
}

/** Marcha actual y sugerencia. Mientras aprende, muestra el progreso. */
@Composable
private fun GearBadge(gear: Int?, suggestion: Int?, learned: Int, total: Int) {
    when {
        learned < total -> Text("Aprendiendo marchas ${minOf(learned, total)} de $total", style = LabelStyle)
        suggestion != null && gear != null -> {
            val up = suggestion > gear
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(Eco.Teal).padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (up) "↑" else "↓", style = numberStyle(30, FontWeight.Bold), color = Eco.Pine)
                Spacer(Modifier.width(6.dp))
                Text("${suggestion}ª", style = numberStyle(34, FontWeight.Bold), color = Eco.Pine)
            }
        }
        gear != null -> Box(
            Modifier.clip(RoundedCornerShape(14.dp)).background(Eco.Surface).padding(horizontal = 16.dp, vertical = 6.dp),
        ) { Text("${gear}ª", style = numberStyle(34), color = Eco.Lichen) }
        else -> Box(
            Modifier.clip(RoundedCornerShape(14.dp)).background(Eco.Surface).padding(horizontal = 16.dp, vertical = 6.dp),
        ) { Text("–", style = numberStyle(34), color = Eco.Dim) }
    }
}

@Composable
private fun SegmentButton(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(24.dp)).background(if (selected) Eco.Leaf else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Eco.Pine else Eco.Dim, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

private fun statusLine(s: EngineSnapshot, total: Boolean): String = when {
    total -> "Acumulado de ${s.totals.trips} ${if (s.totals.trips == 1) "viaje" else "viajes"}"
    s.state == TripState.WAITING -> "El viaje empezará al superar 5 km/h"
    s.state == TripState.FINISHED -> "Viaje finalizado"
    s.moving -> if (s.ecoActive) "En marcha, sin consumir" else "En marcha"
    else -> "Parado"
}

private fun statusColor(s: EngineSnapshot, total: Boolean): Color = when {
    total || s.state != TripState.RUNNING -> Eco.Dim
    s.ecoActive -> Eco.Teal
    s.moving -> Eco.Leaf
    else -> Eco.Ochre
}

// ------------------------------------------------------------------ páginas

@Composable
private fun TimesPage(t: TripStats, s: EngineSnapshot, total: Boolean) {
    val live = !total && s.state == TripState.RUNNING
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.Center) {
        TimerBlock("En marcha", t.movingMs, Eco.Leaf, active = live && s.moving, dimmed = live && !s.moving)
        Spacer(Modifier.height(18.dp))
        TimerBlock("Parado", t.stoppedMs, Eco.Ochre, active = live && !s.moving, dimmed = live && s.moving)
        Spacer(Modifier.height(18.dp))
        Text("Tiempo total  ${fmtDuration(t.totalMs)}", style = LabelStyle, modifier = Modifier.padding(start = 18.dp))
    }
}

@Composable
private fun TimerBlock(label: String, ms: Long, color: Color, active: Boolean, dimmed: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(6.dp).height(84.dp).clip(RoundedCornerShape(3.dp))
                .background(if (active) color else color.copy(alpha = 0.25f)),
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label, style = LabelStyle.copy(color = if (dimmed) Eco.Dim else color, fontSize = 17.sp))
            Text(fmtDuration(ms), style = numberStyle(64), color = if (dimmed) Eco.Dim else Eco.Lichen)
        }
    }
}

@Composable
private fun SplitPage(t: TripStats) {
    val pct = t.stoppedPct()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        SplitRing(if (t.totalMs > 0) t.stoppedMs.toFloat() / t.totalMs else 0f, Modifier.size(230.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$pct %", style = numberStyle(58), color = Eco.Lichen)
                Text("del tiempo parado", style = LabelStyle)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Legend(Eco.Leaf, "En marcha ${if (t.totalMs > 0) 100 - pct else 0} %")
            Legend(Eco.Ochre, "Parado $pct %")
        }
    }
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = BodyStyle)
    }
}

@Composable
private fun DistancePage(t: TripStats) {
    val real = t.avgSpeedKmh()
    val moving = t.movingAvgSpeedKmh()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(fmtKm(t.distanceKm), style = numberStyle(80), color = Eco.Lichen)
        Text("km recorridos", style = LabelStyle)
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BigStat(fmtNum(real, 0), "km/h de media real", Eco.Ochre)
            BigStat(fmtNum(moving, 0), "km/h de media en marcha", Eco.Leaf)
        }
        if (moving - real >= 2) {
            Spacer(Modifier.height(20.dp))
            Text(
                "Las paradas bajan tu media de ${fmtNum(moving, 0)} a ${fmtNum(real, 0)} km/h.",
                style = BodyStyle.copy(color = Eco.Dim), textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun BigStat(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(150.dp)) {
        Text(value, style = numberStyle(44), color = color)
        Text(label, style = LabelStyle, textAlign = TextAlign.Center)
    }
}

@Composable
private fun EcoPage(t: TripStats, s: EngineSnapshot, total: Boolean, settings: AppSettings) {
    val pct = t.ecoDistancePct()
    val real = savedLitersReal(t, settings)
    val max = savedLitersMax(t, settings)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LeafMark(30.dp, if (!total && s.ecoActive) Eco.Teal else Eco.Line)
            Spacer(Modifier.width(10.dp))
            Text(fmtKm(t.ecoKm), style = numberStyle(72), color = Eco.Teal)
        }
        Text("km sin consumir combustible", style = LabelStyle)
        Spacer(Modifier.height(18.dp))
        EcoScale(pct)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BigStat(fmtDuration(t.ecoMs), "sin inyectar", Eco.Lichen)
            BigStat(fmtEuro(real * settings.fuelPrice), "ahorrados (${fmtNum(real, 2)} L)", Eco.Teal)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Con tu consumo medio serían hasta ${fmtEuro(max * settings.fuelPrice)}",
            style = LabelStyle, textAlign = TextAlign.Center,
        )
    }
}

/** Escala eco: % del recorrido en corte de inyección. 25 % o más es conducción muy eficiente. */
@Composable
private fun EcoScale(pct: Int) {
    val frac = (pct / 25f).coerceIn(0f, 1f)
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(Eco.Line)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(7.dp)).background(Eco.Teal))
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("$pct % del recorrido", style = LabelStyle, modifier = Modifier.weight(1f))
            Text(
                when { pct >= 20 -> "Excelente"; pct >= 12 -> "Muy bien"; pct >= 6 -> "Bien"; else -> "Mejorable" },
                style = LabelStyle.copy(color = Eco.Teal),
            )
        }
    }
}

@Composable
private fun ScorePage(t: TripStats) {
    val score = t.ecoScore()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScoreGauge(score, Modifier.size(210.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (score < 0) "—" else "$score", style = numberStyle(68), color = Eco.Lichen)
                Text(if (score < 0) "recorre unos metros" else "puntuación eco", style = LabelStyle)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SmallStat("${t.harshAccel}", "acelerones")
            SmallStat("${t.harshBrake}", "frenazos")
            SmallStat(fmtDuration(t.idleMs), "al ralentí")
        }
    }
}

@Composable
private fun SmallStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = numberStyle(32), color = Eco.Lichen)
        Text(label, style = LabelStyle)
    }
}

package com.ecotrayecto

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ecotrayecto.data.AppState
import com.ecotrayecto.ui.DashboardScreen
import com.ecotrayecto.ui.DtcScreen
import com.ecotrayecto.ui.Eco
import com.ecotrayecto.ui.EcoTheme
import com.ecotrayecto.ui.HistoryScreen
import com.ecotrayecto.ui.LabelStyle
import com.ecotrayecto.ui.LeafMark
import com.ecotrayecto.ui.SettingsScreen
import com.ecotrayecto.ui.asState
import com.ecotrayecto.ui.BatteryIndicator
import com.ecotrayecto.ui.numberStyle
import java.io.File
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.init(this)
        @Suppress("DEPRECATION")
        window.statusBarColor = 0xFF13241C.toInt()
        @Suppress("DEPRECATION")
        window.navigationBarColor = 0xFF1C3127.toInt()
        setContent { EcoTheme { EcoApp() } }
    }
}

fun requiredPermissions(): Array<String> {
    val list = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= 31) {
        list += Manifest.permission.BLUETOOTH_CONNECT
        list += Manifest.permission.BLUETOOTH_SCAN
    } else {
        list += Manifest.permission.ACCESS_FINE_LOCATION
    }
    if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
    return list.toTypedArray()
}

@Composable
fun EcoApp() {
    val context = LocalContext.current
    val settings by AppState.settings.asState()
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    LaunchedEffect(Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    // Mantener la pantalla encendida mientras la app está delante.
    DisposableEffect(settings.keepScreenOn) {
        val window = (context as? Activity)?.window
        if (settings.keepScreenOn) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { }
    }

    if (showSplash) {
        SplashScreen(settings.brand, AppState.storage.logoFile) { showSplash = false }
        return
    }

    Scaffold(
        containerColor = Eco.Pine,
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(Eco.Pine).statusBarsPadding().padding(start = 20.dp, end = 16.dp, top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Spacer(Modifier.weight(1f))
                BatteryIndicator()
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Eco.Surface) {
                val colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Eco.Pine, selectedTextColor = Eco.Lichen,
                    indicatorColor = Eco.Leaf, unselectedIconColor = Eco.Dim, unselectedTextColor = Eco.Dim,
                )
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Panel") }, colors = colors)
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.List, null) }, label = { Text("Historial") }, colors = colors)
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Build, null) }, label = { Text("Averías") }, colors = colors)
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Ajustes") }, colors = colors)
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize().background(Eco.Pine)) {
            when (tab) {
                0 -> DashboardScreen(onOpenSettings = { tab = 3 })
                1 -> HistoryScreen()
                2 -> DtcScreen()
                else -> SettingsScreen()
            }
        }
    }
}

fun loadScaledBitmap(file: File, maxPx: Int = 512): ImageBitmap? {
    if (!file.exists()) return null
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxPx * 2 || bounds.outHeight / sample > maxPx * 2) sample *= 2
        BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
    } catch (e: Exception) { null }
}

@Composable
fun SplashScreen(brand: String, logoFile: File, onDone: () -> Unit) {
    val logo = remember { loadScaledBitmap(logoFile) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(700))
        delay(1900)
        onDone()
    }
    Column(
        Modifier.fillMaxSize().background(Eco.Pine).alpha(alpha.value).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (logo != null) {
            Image(logo, contentDescription = brand, modifier = Modifier.size(180.dp))
        } else {
            LeafMark(96.dp)
        }
        Spacer(Modifier.height(28.dp))
        Text(
            if (brand.isNotEmpty()) brand else "EcoTrayecto",
            style = numberStyle(44, FontWeight.Medium), color = Eco.Lichen, textAlign = TextAlign.Center,
        )
        if (brand.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("EcoTrayecto", style = LabelStyle)
        }
    }
}

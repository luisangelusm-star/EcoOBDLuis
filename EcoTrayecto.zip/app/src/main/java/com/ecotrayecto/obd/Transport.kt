package com.ecotrayecto.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Build
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Canal de bytes con el adaptador. Todas las llamadas son bloqueantes (se usan desde un hilo propio). */
interface ObdTransport {
    @Throws(IOException::class) fun connect()
    @Throws(IOException::class) fun write(text: String)
    /** Siguiente bloque de bytes recibido, o null si vence el tiempo. */
    @Throws(IOException::class) fun poll(timeoutMs: Long): ByteArray?
    fun clearInput()
    fun close()
}

/** ELM327 por Bluetooth clásico (SPP), el más habitual. */
@SuppressLint("MissingPermission")
class ClassicTransport(private val device: BluetoothDevice) : ObdTransport {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override fun connect() {
        val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        val s = try {
            device.createRfcommSocketToServiceRecord(spp).also { it.connect() }
        } catch (e: IOException) {
            // Muchos clones solo aceptan el canal 1 directamente.
            try {
                val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                (m.invoke(device, 1) as BluetoothSocket).also { it.connect() }
            } catch (e2: Exception) {
                throw IOException("No se pudo conectar con ${device.name ?: device.address}", e)
            }
        }
        socket = s
        input = s.inputStream
        output = s.outputStream
    }

    override fun write(text: String) {
        val out = output ?: throw IOException("Sin conexión")
        out.write(text.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    override fun poll(timeoutMs: Long): ByteArray? {
        val inp = input ?: throw IOException("Sin conexión")
        val end = System.currentTimeMillis() + timeoutMs
        val buf = ByteArray(256)
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val n = inp.read(buf)
                if (n < 0) throw IOException("Conexión cerrada")
                return buf.copyOf(n)
            }
            Thread.sleep(5)
        }
        return null
    }

    override fun clearInput() {
        try {
            val inp = input ?: return
            while (inp.available() > 0) inp.read(ByteArray(inp.available()))
        } catch (_: IOException) { }
    }

    override fun close() {
        try { socket?.close() } catch (_: IOException) { }
        socket = null; input = null; output = null
    }
}

/** ELM327 Bluetooth LE (Vgate, OBDLink CX, Veepeak BLE...). Busca sola las características. */
@SuppressLint("MissingPermission")
class BleTransport(private val context: Context, private val device: BluetoothDevice) : ObdTransport {
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    private var servicesLatch = CountDownLatch(1)
    private var descriptorLatch = CountDownLatch(1)
    @Volatile private var writeLatch = CountDownLatch(1)
    @Volatile private var connected = false

    private val ignoredServices = setOf(0x1800, 0x1801, 0x180A, 0x180F)
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                servicesLatch.countDown(); descriptorLatch.countDown(); writeLatch.countDown()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) { servicesLatch.countDown() }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            descriptorLatch.countDown()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writeLatch.countDown()
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            queue.offer(value.copyOf())
        }

        @Deprecated("Android 12 e inferiores")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return
            @Suppress("DEPRECATION")
            c.value?.let { queue.offer(it.copyOf()) }
        }
    }

    override fun connect() {
        servicesLatch = CountDownLatch(1)
        descriptorLatch = CountDownLatch(1)
        val g = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
            ?: throw IOException("No se pudo abrir la conexión BLE")
        gatt = g
        if (!servicesLatch.await(15, TimeUnit.SECONDS) || !connected) {
            close(); throw IOException("El adaptador BLE no responde")
        }

        var notifyChar: BluetoothGattCharacteristic? = null
        var wChar: BluetoothGattCharacteristic? = null
        for (service in g.services) {
            val short = shortUuid(service.uuid)
            if (short != null && short in ignoredServices) continue
            var n: BluetoothGattCharacteristic? = null
            var w: BluetoothGattCharacteristic? = null
            for (c in service.characteristics) {
                val p = c.properties
                if (n == null && (p and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) n = c
                if (w == null && (p and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) w = c
            }
            if (n != null && w != null) { notifyChar = n; wChar = w; break }
        }
        if (notifyChar == null || wChar == null) {
            close(); throw IOException("Este dispositivo BLE no parece un adaptador OBD")
        }
        writeChar = wChar

        g.setCharacteristicNotification(notifyChar, true)
        val desc = notifyChar.getDescriptor(cccd)
        if (desc != null) {
            val value = if ((notifyChar.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(desc, value)
            } else {
                @Suppress("DEPRECATION")
                desc.value = value
                @Suppress("DEPRECATION")
                g.writeDescriptor(desc)
            }
            descriptorLatch.await(5, TimeUnit.SECONDS)
        }
    }

    override fun write(text: String) {
        val g = gatt ?: throw IOException("Sin conexión")
        val c = writeChar ?: throw IOException("Sin conexión")
        if (!connected) throw IOException("Adaptador BLE desconectado")
        val noResp = (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        val type = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        val bytes = text.toByteArray(Charsets.US_ASCII)
        var i = 0
        while (i < bytes.size) {
            val chunk = bytes.copyOfRange(i, minOf(bytes.size, i + 20))
            writeLatch = CountDownLatch(1)
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, type)
            } else {
                @Suppress("DEPRECATION")
                c.writeType = type
                @Suppress("DEPRECATION")
                c.value = chunk
                @Suppress("DEPRECATION")
                g.writeCharacteristic(c)
            }
            writeLatch.await(if (noResp) 100 else 1000, TimeUnit.MILLISECONDS)
            i += 20
        }
    }

    override fun poll(timeoutMs: Long): ByteArray? {
        if (!connected) throw IOException("Adaptador BLE desconectado")
        return queue.poll(timeoutMs, TimeUnit.MILLISECONDS)
    }

    override fun clearInput() { queue.clear() }

    override fun close() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) { }
        gatt = null
        connected = false
    }

    private fun shortUuid(u: UUID): Int? {
        val s = u.toString().lowercase()
        return if (s.endsWith("-0000-1000-8000-00805f9b34fb") && s.startsWith("0000")) s.substring(4, 8).toInt(16) else null
    }
}

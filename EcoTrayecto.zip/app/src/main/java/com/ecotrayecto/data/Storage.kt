package com.ecotrayecto.data

import android.content.Context
import com.ecotrayecto.trip.TripStats
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Totales, historial de viajes y viaje en curso, guardados como JSON en la memoria interna. */
class Storage(ctx: Context) {
    private val dir = ctx.filesDir
    private val totalsFile = File(dir, "totales.json")
    private val historyFile = File(dir, "historial.json")
    private val pendingFile = File(dir, "viaje_en_curso.json")
    val logoFile = File(dir, "logo_marca")

    private val maxHistory = 500

    @Synchronized fun loadTotals(): TripStats = read(totalsFile)?.let { fromJson(JSONObject(it)) } ?: TripStats()
    @Synchronized fun saveTotals(t: TripStats) = write(totalsFile, toJson(t).toString())

    @Synchronized
    fun loadHistory(): List<TripStats> {
        val txt = read(historyFile) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(txt)
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun addToHistory(t: TripStats) {
        if (t.totalMs < 30_000 && t.distanceM < 100) return // ignora "viajes" de prueba de unos segundos
        val list = (listOf(t) + loadHistory()).take(maxHistory)
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        write(historyFile, arr.toString())
    }

    @Synchronized fun clearHistory() { historyFile.delete() }

    @Synchronized fun savePending(t: TripStats?) {
        if (t == null) pendingFile.delete() else write(pendingFile, toJson(t).toString())
    }

    @Synchronized fun takePending(): TripStats? {
        val t = read(pendingFile)?.let { runCatching { fromJson(JSONObject(it)) }.getOrNull() }
        pendingFile.delete()
        return t
    }

    private fun read(f: File): String? = if (f.exists()) runCatching { f.readText() }.getOrNull() else null

    private fun write(f: File, txt: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(txt)
        tmp.renameTo(f)
    }

    private fun toJson(t: TripStats) = JSONObject()
        .put("movingMs", t.movingMs).put("stoppedMs", t.stoppedMs).put("distanceM", t.distanceM)
        .put("ecoMs", t.ecoMs).put("ecoDistanceM", t.ecoDistanceM).put("idleMs", t.idleMs)
        .put("longIdleMs", t.longIdleMs).put("harshAccel", t.harshAccel).put("harshBrake", t.harshBrake)
        .put("trips", t.trips).put("startTime", t.startTime).put("endTime", t.endTime)

    private fun fromJson(o: JSONObject) = TripStats(
        movingMs = o.optLong("movingMs"), stoppedMs = o.optLong("stoppedMs"), distanceM = o.optDouble("distanceM", 0.0),
        ecoMs = o.optLong("ecoMs"), ecoDistanceM = o.optDouble("ecoDistanceM", 0.0), idleMs = o.optLong("idleMs"),
        longIdleMs = o.optLong("longIdleMs"), harshAccel = o.optInt("harshAccel"), harshBrake = o.optInt("harshBrake"),
        trips = o.optInt("trips"), startTime = o.optLong("startTime"), endTime = o.optLong("endTime"),
    )
}

package com.ecotrayecto.ui

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ecotrayecto.data.AdapterType
import com.ecotrayecto.data.AppSettings
import com.ecotrayecto.data.AppState
import com.ecotrayecto.data.FuelType
import kotlin.math.roundToInt

private val BRANDS = listOf(
    "Abarth", "Alfa Romeo", "Audi", "BMW", "Citroën", "Cupra", "Dacia", "DS", "Fiat", "Ford", "Honda",
    "Hyundai", "Jaguar", "Jeep", "Kia", "Lancia", "Land Rover", "Lexus", "Mazda", "Mercedes-Benz", "MG",
    "Mini", "Mitsubishi", "Nissan", "Opel", "Peugeot", "Porsche", "Renault", "Seat", "Škoda", "Smart",
    "SsangYong", "Subaru", "Suzuki", "Toyota", "Volkswagen", "Volvo",
)

data class FoundDevice(val name: String, val address: String)

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val s by AppState.settings.asState()
    val live by AppState.live.asState()
    fun update(n: AppSettings) = AppState.updateSettings(context, n)

    var pickDevice by rememberSaveable { mutableStateOf(false) }
    var pickBrand by rememberSaveable { mutableStateOf(false) }
    var logoVersion by remember { mutableIntStateOf(0) }
    val hasLogo = remember(logoVersion) { AppState.storage.logoFile.exists() }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    AppState.storage.logoFile.outputStream().use { input.copyTo(it) }
                }
            }
            logoVersion++
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Ajustes", style = TitleStyle)

        Section("Adaptador OBD") {
            Text("Tipo de Bluetooth", style = LabelStyle)
            RadioRow("Clásico (se empareja con PIN 1234 o 0000)", s.adapterType == AdapterType.CLASSIC) {
                update(s.copy(adapterType = AdapterType.CLASSIC, deviceAddress = "", deviceName = ""))
            }
            RadioRow("Bluetooth LE (Vgate, OBDLink CX, Veepeak BLE…)", s.adapterType == AdapterType.BLE) {
                update(s.copy(adapterType = AdapterType.BLE, deviceAddress = "", deviceName = ""))
            }
            Spacer(Modifier.height(4.dp))
            Text(if (s.deviceName.isNotEmpty()) "Adaptador: ${s.deviceName}" else "Ningún adaptador elegido", style = BodyStyle)
            OutlinedButton({ pickDevice = true }, Modifier.fillMaxWidth()) { Text("Elegir adaptador", color = Eco.Lichen) }
            Text("Los cambios de adaptador se aplican al volver a conectar.", style = LabelStyle)
        }

        Section("Vehículo") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (s.brand.isEmpty()) "Marca sin elegir" else "Marca: ${s.brand}", style = BodyStyle, modifier = Modifier.weight(1f))
                TextButton({ pickBrand = true }) { Text("Cambiar", color = Eco.Teal) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (hasLogo) "Logotipo cargado" else "Sin logotipo (se muestra la hoja)", style = BodyStyle, modifier = Modifier.weight(1f))
                if (hasLogo) TextButton({ AppState.storage.logoFile.delete(); logoVersion++ }) { Text("Quitar", color = Eco.Dim) }
                TextButton({ logoPicker.launch("image/*") }) { Text("Elegir imagen", color = Eco.Teal) }
            }
            Text("El logotipo se muestra unos segundos al abrir la app. Usa una imagen propia de tu galería.", style = LabelStyle)

            Spacer(Modifier.height(4.dp))
            Text("Combustible", style = LabelStyle)
            RadioRow("Gasolina", s.fuelType == FuelType.GASOLINA) {
                update(s.copy(fuelType = FuelType.GASOLINA, idleConsumption = if (s.idleConsumption == 0.6) 0.8 else s.idleConsumption,
                    upshiftRpm = if (s.upshiftRpm == 2000) 2500 else s.upshiftRpm))
            }
            RadioRow("Diésel", s.fuelType == FuelType.DIESEL) {
                update(s.copy(fuelType = FuelType.DIESEL, idleConsumption = if (s.idleConsumption == 0.8) 0.6 else s.idleConsumption,
                    upshiftRpm = if (s.upshiftRpm == 2500) 2000 else s.upshiftRpm))
            }
            NumberField("Precio del combustible", s.fuelPrice, "€/L") { update(s.copy(fuelPrice = it)) }
            NumberField("Consumo medio del coche", s.avgConsumption, "L/100 km") { update(s.copy(avgConsumption = it)) }
            NumberField("Consumo al ralentí", s.idleConsumption, "L/h") { update(s.copy(idleConsumption = it)) }
            Text("El ahorro se calcula con el consumo al ralentí, que es lo que gastarías bajando en punto muerto. Con el consumo medio se muestra el máximo teórico.", style = LabelStyle)
        }

        Section("Pantallas") {
            SwitchRow("Cambiar de pantalla sola", s.autoRotate) { update(s.copy(autoRotate = it)) }
            if (s.autoRotate) SliderRow("Cada", s.rotateSeconds, 3..20, "s") { update(s.copy(rotateSeconds = it)) }
            SwitchRow("Mantener la pantalla encendida", s.keepScreenOn) { update(s.copy(keepScreenOn = it)) }
        }

        Section("Fin del viaje") {
            SliderRow("Sin comunicación durante", s.endTimeoutSec, 5..30, "s") { update(s.copy(endTimeoutSec = it)) }
            Text("Si se pierde la comunicación menos tiempo (calado y rearranque), el viaje continúa y ese hueco cuenta como parado.", style = LabelStyle)
        }

        Section("Detección sin consumo") {
            SliderRow("Velocidad mínima", s.ecoMinSpeed, 5..40, "km/h") { update(s.copy(ecoMinSpeed = it)) }
            SliderRow("Revoluciones mínimas", s.ecoMinRpm / 50, 16..40, "") { update(s.copy(ecoMinRpm = it * 50)) }
            Text("${s.ecoMinRpm} rpm", style = LabelStyle)
            SliderRow("Carga máxima del motor", s.ecoMaxLoad, 0..10, "%") { update(s.copy(ecoMaxLoad = it)) }
        }

        Section("Marcha recomendada") {
            var confirmForget by remember { mutableStateOf(false) }
            SwitchRow("Mostrar la marcha y la sugerencia de cambio", s.gearAdvice) { update(s.copy(gearAdvice = it)) }
            if (s.gearAdvice) {
                SliderRow("Número de marchas", s.gearCount, 4..7, "") { update(s.copy(gearCount = it)) }
                Text("${s.gearCount} marchas", style = LabelStyle)
                SliderRow("Subir de marcha a partir de", s.upshiftRpm / 100, 15..40, "") { update(s.copy(upshiftRpm = it * 100)) }
                Text("${s.upshiftRpm} rpm (recomendado: 2500 en gasolina, 2000 en diésel)", style = LabelStyle)
                Text("Marchas aprendidas: ${minOf(live.gearsLearned, s.gearCount)} de ${s.gearCount}", style = BodyStyle)
                Text(
                    "Se aprenden solas: circula unos segundos a ritmo constante en cada marcha. " +
                        "La sugerencia aparece si la condición dura más de 1,2 s, para compensar el retraso del adaptador.",
                    style = LabelStyle,
                )
                TextButton({ confirmForget = true }) { Text("Olvidar las marchas aprendidas", color = Eco.Dim) }
            }
            if (confirmForget) {
                AlertDialog(
                    onDismissRequest = { confirmForget = false },
                    containerColor = Eco.Surface, titleContentColor = Eco.Lichen, textContentColor = Eco.Dim,
                    title = { Text("¿Olvidar las marchas?") },
                    text = { Text("Úsalo si cambias de coche. La app volverá a aprenderlas mientras conduces.") },
                    confirmButton = { TextButton({ AppState.forgetGears(); confirmForget = false }) { Text("Olvidar", color = Eco.Danger) } },
                    dismissButton = { TextButton({ confirmForget = false }) { Text("Cancelar", color = Eco.Lichen) } },
                )
            }
        }

        Section("Aviso de ralentí") {
            SwitchRow("Avisar si estoy parado con el motor en marcha", s.idleAlertEnabled) { update(s.copy(idleAlertEnabled = it)) }
            if (s.idleAlertEnabled) SliderRow("Tras", s.idleAlertMin, 1..5, "min") { update(s.copy(idleAlertMin = it)) }
        }

        Section("Calibración") {
            Text("Protocolo: ${live.protocol}", style = BodyStyle)
            Text("Método sin consumo: ${live.ecoMethod}", style = BodyStyle)
            Text("Velocidad de lectura: ${live.speedMode}", style = BodyStyle)
            Text(
                "Ahora: ${live.speed?.let { "$it km/h" } ?: "—"}   ${live.rpm?.let { "$it rpm" } ?: "—"}   " +
                    "carga ${live.load?.let { "$it %" } ?: "—"}" + (live.fuelRate?.let { "   ${fmtNum(it, 2)} L/h" } ?: ""),
                style = BodyStyle,
            )
            Text(
                "Para comprobarlo: circula a más de 50 km/h con una marcha metida y suelta el acelerador. " +
                    "Si la carga baja a 0–2 %, los valores por defecto sirven. Si se queda en 3–5 %, sube la carga máxima.",
                style = LabelStyle,
            )
        }

        Text("EcoTrayecto 1.0. Las marcas citadas pertenecen a sus propietarios.", style = LabelStyle)
        Spacer(Modifier.height(12.dp))
    }

    if (pickDevice) {
        DevicePicker(s.adapterType, onDismiss = { pickDevice = false }) { d ->
            update(s.copy(deviceAddress = d.address, deviceName = d.name))
            pickDevice = false
        }
    }
    if (pickBrand) {
        AlertDialog(
            onDismissRequest = { pickBrand = false },
            containerColor = Eco.Surface, titleContentColor = Eco.Lichen,
            title = { Text("Marca del coche") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    (BRANDS + "Otra").forEach { b ->
                        Text(
                            b, style = BodyStyle,
                            modifier = Modifier.fillMaxWidth().clickable { update(s.copy(brand = if (b == "Otra") "" else b)); pickBrand = false }
                                .padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton({ pickBrand = false }) { Text("Cerrar", color = Eco.Lichen) } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eco.Surface).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, style = BodyStyle.copy(color = Eco.Leaf))
        content()
    }
}

@Composable
private fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Eco.Leaf, unselectedColor = Eco.Dim))
        Text(text, style = BodyStyle)
    }
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = BodyStyle, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Eco.Leaf, checkedThumbColor = Eco.Pine))
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, suffix: String, onChange: (Int) -> Unit) {
    var local by remember(value) { mutableStateOf(value.toFloat()) }
    Column {
        Row {
            Text(label, style = BodyStyle, modifier = Modifier.weight(1f))
            if (suffix.isNotEmpty()) Text("${local.roundToInt()} $suffix", style = BodyStyle.copy(color = Eco.Leaf))
        }
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onChange(local.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = (range.last - range.first - 1).coerceAtLeast(0),
            colors = SliderDefaults.colors(thumbColor = Eco.Leaf, activeTrackColor = Eco.Leaf, inactiveTrackColor = Eco.Line),
        )
    }
}

@Composable
private fun NumberField(label: String, value: Double, suffix: String, onValue: (Double) -> Unit) {
    var text by rememberSaveable(label) { mutableStateOf(fmtNum(value, 2)) }
    OutlinedTextField(
        value = text,
        onValueChange = { new ->
            text = new
            parseDecimal(new)?.takeIf { it > 0 }?.let(onValue)
        },
        label = { Text(label) },
        suffix = { Text(suffix) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}

@SuppressLint("MissingPermission")
@Composable
private fun DevicePicker(type: AdapterType, onDismiss: () -> Unit, onPick: (FoundDevice) -> Unit) {
    val context = LocalContext.current
    val devices = remember { mutableStateListOf<FoundDevice>() }
    var error by remember { mutableStateOf("") }

    DisposableEffect(type) {
        val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        var stop: () -> Unit = {}
        try {
            when {
                adapter == null -> error = "Este móvil no tiene Bluetooth."
                !adapter.isEnabled -> error = "Activa el Bluetooth del móvil."
                type == AdapterType.CLASSIC -> {
                    adapter.bondedDevices.forEach { devices += FoundDevice(it.name ?: it.address, it.address) }
                    if (devices.isEmpty()) error = "No hay dispositivos emparejados. Empareja el adaptador en los ajustes de Bluetooth del móvil (PIN 1234 o 0000)."
                }
                else -> {
                    val scanner = adapter.bluetoothLeScanner
                    val cb = object : ScanCallback() {
                        override fun onScanResult(callbackType: Int, result: ScanResult) {
                            val d = result.device
                            val name = d.name ?: result.scanRecord?.deviceName ?: return
                            if (devices.none { it.address == d.address }) devices += FoundDevice(name, d.address)
                        }
                    }
                    scanner?.startScan(cb)
                    stop = { runCatching { scanner?.stopScan(cb) } }
                }
            }
        } catch (e: SecurityException) {
            error = "Falta el permiso de Bluetooth. Concédelo en los ajustes de la app."
        }
        onDispose { stop() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Eco.Surface, titleContentColor = Eco.Lichen, textContentColor = Eco.Dim,
        title = { Text(if (type == AdapterType.CLASSIC) "Adaptadores emparejados" else "Buscando adaptadores BLE…") },
        text = {
            Column {
                if (error.isNotEmpty()) Text(error, style = BodyStyle.copy(color = Eco.Ochre))
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    devices.forEach { d ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(d) }.padding(vertical = 10.dp)) {
                            Text(d.name, style = BodyStyle)
                            Text(d.address, style = LabelStyle)
                        }
                    }
                }
                if (type == AdapterType.BLE) Text("Enciende el coche o da el contacto para que el adaptador aparezca.", style = LabelStyle)
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Cerrar", color = Eco.Lichen) } },
    )
}

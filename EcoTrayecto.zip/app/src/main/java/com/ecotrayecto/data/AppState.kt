package com.ecotrayecto.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.ecotrayecto.trip.EngineSnapshot
import com.ecotrayecto.trip.GearAdvisor
import com.ecotrayecto.trip.TripEngine
import com.ecotrayecto.trip.TripListener
import com.ecotrayecto.trip.TripStats
import java.util.concurrent.CopyOnWriteArrayList

/** Valor observable sencillo; avisa a los observadores en el hilo principal. */
class Observable<T>(initial: T) {
    @Volatile var value: T = initial
        private set
    private val listeners = CopyOnWriteArrayList<(T) -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun set(v: T) {
        value = v
        main.post { listeners.forEach { it(v) } }
    }

    fun observe(l: (T) -> Unit): () -> Unit {
        listeners.add(l)
        l(value)
        return { listeners.remove(l) }
    }
}

enum class ConnStatus { OFF, CONNECTING, WAITING_CAR, CONNECTED, ERROR }

data class LiveInfo(
    val status: ConnStatus = ConnStatus.OFF,
    val message: String = "Sin conectar",
    val protocol: String = "—",
    val speed: Int? = null,
    val rpm: Int? = null,
    val load: Int? = null,
    val coolant: Int? = null,
    val fuelRate: Double? = null,
    val ecoMethod: String = "—",
    val speedMode: String = "—",
    val voltage: Double? = null,
    val gear: Int? = null,
    val gearSuggestion: Int? = null,
    val gearsLearned: Int = 0,
)

data class DtcInfo(
    val busy: Boolean = false,
    val stored: List<String>? = null,
    val pending: List<String>? = null,
    val message: String = "",
)

enum class DtcRequest { READ, CLEAR }

object AppState {
    lateinit var storage: Storage
        private set
    lateinit var engine: TripEngine
        private set
    lateinit var gears: GearAdvisor
        private set
    private lateinit var appContext: Context

    val settings = Observable(AppSettings())
    val live = Observable(LiveInfo())
    lateinit var trip: Observable<EngineSnapshot>
        private set
    val history = Observable<List<TripStats>>(emptyList())
    val dtc = Observable(DtcInfo())

    @Volatile var dtcRequest: DtcRequest? = null
    @Volatile var serviceRunning = false
    @Volatile var onIdleAlert: (() -> Unit)? = null

    private var initialized = false

    @Synchronized
    fun init(ctx: Context) {
        if (initialized) return
        val app = ctx.applicationContext
        appContext = app
        storage = Storage(app)
        val s = SettingsStore.load(app)
        settings.set(s)

        // Si la app se cerró de golpe con un viaje en curso, lo recuperamos en el total.
        val totals = storage.loadTotals()
        storage.takePending()?.let { p ->
            totals.add(p)
            storage.saveTotals(totals)
            storage.addToHistory(p)
        }

        engine = TripEngine(s.engineConfig(), totals, object : TripListener {
            override fun onTripFinished(trip: TripStats) {
                storage.saveTotals(engine.savedTotals())
                storage.addToHistory(trip)
                storage.savePending(null)
                history.set(storage.loadHistory())
            }
            override fun onIdleAlert() { onIdleAlert?.invoke() }
        })
        gears = GearAdvisor(SettingsStore.loadGears(app), s.gearConfig())
        live.set(live.value.copy(gearsLearned = gears.validGears().size))
        trip = Observable(engine.snapshot())
        history.set(storage.loadHistory())
        initialized = true
    }

    fun updateSettings(ctx: Context, s: AppSettings) {
        SettingsStore.save(ctx.applicationContext, s)
        settings.set(s)
        engine.config = s.engineConfig()
        gears.config = s.gearConfig()
        live.set(live.value.copy(gearsLearned = gears.validGears().size))
    }

    fun saveGearsIfChanged() {
        if (gears.changed) SettingsStore.saveGears(appContext, gears.export())
    }

    fun forgetGears() {
        gears.forget()
        SettingsStore.saveGears(appContext, gears.export())
        live.set(live.value.copy(gearsLearned = 0, gear = null, gearSuggestion = null))
    }

    fun publishTrip() = trip.set(engine.snapshot())

    fun resetTrip() {
        val closed = engine.resetTrip(System.currentTimeMillis())
        if (closed != null) {
            storage.saveTotals(engine.savedTotals())
            storage.addToHistory(closed)
            storage.savePending(null)
            history.set(storage.loadHistory())
        }
        publishTrip()
    }

    fun resetTotals() {
        engine.resetTotals()
        storage.saveTotals(TripStats())
        publishTrip()
    }

    fun dismissIdleAlert() {
        engine.dismissIdleAlert()
        publishTrip()
    }

    fun clearHistory() {
        storage.clearHistory()
        history.set(emptyList())
    }
}

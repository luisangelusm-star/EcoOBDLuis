package com.ecotrayecto.obd

import java.io.IOException

/** Comunicación con el ELM327 sobre cualquier transporte. Uso desde un único hilo. */
class Elm327(private val t: ObdTransport) {

    var isCan = true
        private set
    var protocolName = "—"
        private set
    var supported: Set<Int> = emptySet()
        private set

    private var multiOk: Boolean? = null   // null = aún no se sabe
    private var countOk = false            // el adaptador acepta "esperar 1 respuesta"
    val speedMode: String
        get() = when {
            multiOk == true && countOk -> "Rápido (petición múltiple + respuesta inmediata)"
            multiOk == true -> "Rápido (petición múltiple)"
            countOk -> "Medio (respuesta inmediata)"
            else -> "Normal"
        }

    @Throws(IOException::class)
    fun command(cmd: String, timeoutMs: Long = 2000): String {
        t.clearInput()
        t.write(cmd + "\r")
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) break
            val chunk = t.poll(left) ?: break
            sb.append(String(chunk, Charsets.US_ASCII))
            if (sb.indexOf(">") >= 0) break
        }
        if (sb.indexOf(">") < 0) return "TIMEOUT"
        return sb.toString().replace(">", "").replace("\u0000", "").trim()
    }

    @Throws(IOException::class)
    fun initialize() {
        command("ATZ", 4000)
        Thread.sleep(300)
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATAT2", "ATSP0")) command(c)
    }

    /**
     * Busca el protocolo del coche (CAN, K-Line...) y los PIDs soportados.
     * Devuelve false si el coche no responde (contacto quitado).
     */
    @Throws(IOException::class)
    fun detectVehicle(): Boolean {
        val r = command("0100", 20_000) // la primera búsqueda en K-Line puede tardar
        val d = ObdParser.pidData(r, 0x00) ?: return false
        val set = HashSet(ObdParser.supportedPids(d, 0x00))
        if (0x20 in set) ObdParser.pidData(command("0120", 3000), 0x20)?.let { set += ObdParser.supportedPids(it, 0x20) }
        if (0x40 in set) ObdParser.pidData(command("0140", 3000), 0x40)?.let { set += ObdParser.supportedPids(it, 0x40) }
        supported = set
        val dpn = command("ATDPN")
        isCan = ObdParser.isCanProtocol(dpn)
        protocolName = ObdParser.protocolName(dpn)
        countOk = ObdParser.pidData(command("010D1", 1500), 0x0D) != null
        multiOk = if (isCan) null else false
        return true
    }

    fun has(pid: Int) = supported.isEmpty() || pid in supported

    @Throws(IOException::class)
    fun pid(pid: Int, timeoutMs: Long = 1500): IntArray? =
        ObdParser.pidData(command("01" + "%02X".format(pid) + (if (countOk) "1" else ""), timeoutMs), pid)

    /**
     * Lee varios PIDs de la forma más rápida que admita el adaptador. El primero debe ser la velocidad.
     * Devuelve un mapa vacío si el coche no responde.
     */
    @Throws(IOException::class)
    fun readMany(pids: List<Int>): Map<Int, IntArray> {
        if (isCan && pids.size > 1 && multiOk != false) {
            val raw = command("01" + pids.take(6).joinToString("") { "%02X".format(it) } + (if (countOk) "1" else ""), 1500)
            val m = ObdParser.parseMultiPid(raw, pids.take(6))
            if (m != null) { multiOk = true; return m }
            val noCar = ObdParser.isError(raw) && !raw.contains("?")
            if (noCar || multiOk == true) return emptyMap()
            multiOk = false // este adaptador no lo soporta: pasamos a uno a uno
        }
        val out = HashMap<Int, IntArray>()
        for (p in pids) {
            val d = pid(p)
            if (d != null) out[p] = d else if (p == pids.first()) return emptyMap()
        }
        return out
    }

    @Throws(IOException::class)
    fun readDtcs(pending: Boolean): List<String> {
        val raw = command(if (pending) "07" else "03", 6000)
        return ObdParser.parseDtcs(raw, if (pending) "47" else "43", isCan)
    }

    @Throws(IOException::class)
    fun clearDtcs(): Boolean {
        val r = command("04", 6000)
        return r.replace(" ", "").contains("44")
    }

    @Throws(IOException::class)
    fun batteryVoltage(): Double? = ObdParser.voltage(command("ATRV"))
}

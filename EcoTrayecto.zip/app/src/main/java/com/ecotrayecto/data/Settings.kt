package com.ecotrayecto.data

import android.content.Context
import com.ecotrayecto.trip.EngineConfig
import com.ecotrayecto.trip.GearCluster
import com.ecotrayecto.trip.GearConfig
import com.ecotrayecto.trip.GearAdvisor

enum class AdapterType { CLASSIC, BLE }
enum class FuelType { GASOLINA, DIESEL }

data class AppSettings(
    val adapterType: AdapterType = AdapterType.CLASSIC,
    val deviceAddress: String = "",
    val deviceName: String = "",
    val brand: String = "",
    val fuelType: FuelType = FuelType.GASOLINA,
    val fuelPrice: Double = 1.60,
    val avgConsumption: Double = 6.5,     // L/100 km
    val idleConsumption: Double = 0.8,    // L/h al ralentí
    val autoRotate: Boolean = true,
    val rotateSeconds: Int = 6,
    val keepScreenOn: Boolean = true,
    val endTimeoutSec: Int = 10,
    val ecoMinSpeed: Int = 15,
    val ecoMinRpm: Int = 1100,
    val ecoMaxLoad: Int = 2,
    val idleAlertEnabled: Boolean = true,
    val idleAlertMin: Int = 2,
    val gearAdvice: Boolean = true,
    val gearCount: Int = 5,
    val upshiftRpm: Int = 2500,
) {
    fun gearConfig() = GearConfig(
        enabled = gearAdvice,
        gearCount = gearCount,
        upshiftRpm = upshiftRpm,
        minRpmAfterUp = if (fuelType == FuelType.DIESEL) 1150 else 1300,
        luggingRpm = if (fuelType == FuelType.DIESEL) 1050 else 1200,
    )

    fun engineConfig() = EngineConfig(
        endTimeoutMs = endTimeoutSec * 1000L,
        ecoMinSpeedKmh = ecoMinSpeed,
        ecoMinRpm = ecoMinRpm,
        ecoMaxLoadPct = ecoMaxLoad,
        idleAlertMs = if (idleAlertEnabled) idleAlertMin * 60_000L else 0L,
    )
}

object SettingsStore {
    private const val FILE = "ajustes"

    fun load(ctx: Context): AppSettings {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = AppSettings()
        return AppSettings(
            adapterType = runCatching { AdapterType.valueOf(p.getString("adapterType", d.adapterType.name)!!) }.getOrDefault(d.adapterType),
            deviceAddress = p.getString("deviceAddress", d.deviceAddress) ?: "",
            deviceName = p.getString("deviceName", d.deviceName) ?: "",
            brand = p.getString("brand", d.brand) ?: "",
            fuelType = runCatching { FuelType.valueOf(p.getString("fuelType", d.fuelType.name)!!) }.getOrDefault(d.fuelType),
            fuelPrice = p.getFloat("fuelPrice", d.fuelPrice.toFloat()).toDouble(),
            avgConsumption = p.getFloat("avgConsumption", d.avgConsumption.toFloat()).toDouble(),
            idleConsumption = p.getFloat("idleConsumption", d.idleConsumption.toFloat()).toDouble(),
            autoRotate = p.getBoolean("autoRotate", d.autoRotate),
            rotateSeconds = p.getInt("rotateSeconds", d.rotateSeconds),
            keepScreenOn = p.getBoolean("keepScreenOn", d.keepScreenOn),
            endTimeoutSec = p.getInt("endTimeoutSec", d.endTimeoutSec),
            ecoMinSpeed = p.getInt("ecoMinSpeed", d.ecoMinSpeed),
            ecoMinRpm = p.getInt("ecoMinRpm", d.ecoMinRpm),
            ecoMaxLoad = p.getInt("ecoMaxLoad", d.ecoMaxLoad),
            idleAlertEnabled = p.getBoolean("idleAlertEnabled", d.idleAlertEnabled),
            idleAlertMin = p.getInt("idleAlertMin", d.idleAlertMin),
            gearAdvice = p.getBoolean("gearAdvice", d.gearAdvice),
            gearCount = p.getInt("gearCount", d.gearCount),
            upshiftRpm = p.getInt("upshiftRpm", d.upshiftRpm),
        )
    }

    fun save(ctx: Context, s: AppSettings) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("adapterType", s.adapterType.name)
            .putString("deviceAddress", s.deviceAddress)
            .putString("deviceName", s.deviceName)
            .putString("brand", s.brand)
            .putString("fuelType", s.fuelType.name)
            .putFloat("fuelPrice", s.fuelPrice.toFloat())
            .putFloat("avgConsumption", s.avgConsumption.toFloat())
            .putFloat("idleConsumption", s.idleConsumption.toFloat())
            .putBoolean("autoRotate", s.autoRotate)
            .putInt("rotateSeconds", s.rotateSeconds)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putInt("endTimeoutSec", s.endTimeoutSec)
            .putInt("ecoMinSpeed", s.ecoMinSpeed)
            .putInt("ecoMinRpm", s.ecoMinRpm)
            .putInt("ecoMaxLoad", s.ecoMaxLoad)
            .putBoolean("idleAlertEnabled", s.idleAlertEnabled)
            .putInt("idleAlertMin", s.idleAlertMin)
            .putBoolean("gearAdvice", s.gearAdvice)
            .putInt("gearCount", s.gearCount)
            .putInt("upshiftRpm", s.upshiftRpm)
            .apply()
    }

    fun loadGears(ctx: Context): List<GearCluster> =
        GearAdvisor.deserialize(ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("gears", "") ?: "")

    fun saveGears(ctx: Context, list: List<GearCluster>) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("gears", GearAdvisor.serialize(list)).apply()
    }
}

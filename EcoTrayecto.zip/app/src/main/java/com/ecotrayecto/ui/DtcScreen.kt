package com.ecotrayecto.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ecotrayecto.data.AppState
import com.ecotrayecto.data.ConnStatus
import com.ecotrayecto.data.DtcRequest

@Composable
fun DtcScreen() {
    val dtc by AppState.dtc.asState()
    val live by AppState.live.asState()
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    val connected = live.status == ConnStatus.CONNECTED

    fun request(r: DtcRequest) {
        AppState.dtcRequest = r
        AppState.dtc.set(dtc.copy(busy = true, message = "Solicitud enviada…"))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Averías", style = TitleStyle)
        Text(
            when (live.status) {
                ConnStatus.CONNECTED -> "Conectado por ${live.protocol}."
                ConnStatus.WAITING_CAR -> "Adaptador conectado. Da el contacto para leer la centralita."
                else -> "Conecta el adaptador desde el Panel para leer las averías."
            },
            style = BodyStyle.copy(color = Eco.Dim),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { request(DtcRequest.READ) }, enabled = connected && !dtc.busy, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Eco.Leaf, contentColor = Eco.Pine),
            ) { Text("Leer averías") }
            OutlinedButton(
                onClick = { confirmClear = true }, enabled = connected && !dtc.busy, modifier = Modifier.weight(1f),
            ) { Text("Borrar averías", color = if (connected) Eco.Lichen else Eco.Dim) }
        }

        if (dtc.message.isNotEmpty()) Text(dtc.message, style = BodyStyle.copy(color = Eco.Ochre))

        dtc.stored?.let { CodeList("Confirmadas", it, "No hay averías confirmadas.") }
        dtc.pending?.let { CodeList("Pendientes", it, "No hay averías pendientes.") }

        if (dtc.stored != null) {
            Text(
                "Las pendientes son fallos detectados una vez que aún no han encendido el testigo. " +
                    "Los códigos P0, P2 y U0 son genéricos; P1, P3 y U1 son propios del fabricante.",
                style = LabelStyle,
            )
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Eco.Surface, titleContentColor = Eco.Lichen, textContentColor = Eco.Dim,
            title = { Text("¿Borrar las averías?") },
            text = {
                Text(
                    "Hazlo con el contacto dado y el motor parado. Se borran los códigos, el testigo y los datos de " +
                        "preparación (readiness): el coche tardará unos trayectos en completarlos, lo que puede afectar a la ITV.",
                )
            },
            confirmButton = { TextButton({ request(DtcRequest.CLEAR); confirmClear = false }) { Text("Borrar", color = Eco.Danger) } },
            dismissButton = { TextButton({ confirmClear = false }) { Text("Cancelar", color = Eco.Lichen) } },
        )
    }
}

@Composable
private fun CodeList(title: String, codes: List<String>, empty: String) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Eco.Surface).padding(16.dp)) {
        Text(title, style = BodyStyle)
        Spacer(Modifier.height(8.dp))
        if (codes.isEmpty()) Text(empty, style = LabelStyle)
        codes.forEach { code ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(code, style = numberStyle(28), color = Eco.Lichen)
                    Text(describe(code), style = LabelStyle)
                }
                TextButton({
                    val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode("código avería $code"))
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                }) { Text("Buscar", color = Eco.Teal) }
            }
        }
    }
}

private fun describe(code: String): String {
    val system = when (code.firstOrNull()) {
        'P' -> "Motor y transmisión"
        'C' -> "Chasis"
        'B' -> "Carrocería"
        'U' -> "Red de comunicaciones"
        else -> "Sistema desconocido"
    }
    val kind = when (code.getOrNull(1)) {
        '0', '2' -> "genérico"
        '1', '3' -> "del fabricante"
        else -> ""
    }
    return "$system, $kind".trimEnd(',', ' ')
}
